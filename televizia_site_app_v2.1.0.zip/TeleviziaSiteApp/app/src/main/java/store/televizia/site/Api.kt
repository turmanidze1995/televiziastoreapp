package store.televizia.site

import android.content.Context
import android.content.SharedPreferences
import android.net.Uri
import android.os.Build
import android.provider.OpenableColumns
import org.json.JSONObject
import java.io.DataOutputStream
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.util.UUID

class UploadFile(val field: String, val uri: Uri)

object Api {
    const val BASE = "https://televizia.store/"
    const val URL_API = BASE + "api/mobile.php"
    lateinit var ctx: Context
    private lateinit var prefs: SharedPreferences

    fun init(c: Context) {
        ctx = c.applicationContext; prefs = ctx.getSharedPreferences("site", Context.MODE_PRIVATE)
        S.lang = prefs.getString("lang", null) ?: java.util.Locale.getDefault().language.let { if (it == "ru" || it == "en") it else "ka" }
    }
    var lang: String
        get() = S.lang
        set(v) { S.lang = v; prefs.edit().putString("lang", v).apply() }
    var token: String
        get() = prefs.getString("token", "") ?: ""
        set(v) { prefs.edit().putString("token", v).apply() }

    private fun enc(s: String) = URLEncoder.encode(s, "UTF-8")

    /** ბლოკავს ნაკადს — გამოიძახეთ ფონური ნაკადიდან */
    fun call(params: List<Pair<String, String>>, files: List<UploadFile> = emptyList()): JSONObject {
        var conn: HttpURLConnection? = null
        try {
            conn = URL(URL_API).openConnection() as HttpURLConnection
            conn.requestMethod = "POST"
            conn.connectTimeout = 15000
            conn.readTimeout = 60000
            conn.doOutput = true
            conn.setRequestProperty("X-Mobile-Token", token)
            conn.setRequestProperty("X-Lang", S.lang)
            conn.setRequestProperty("X-Device", "Android ${Build.VERSION.RELEASE} · ${Build.MANUFACTURER} ${Build.MODEL}")
            conn.setRequestProperty("Accept", "application/json")
            if (files.isEmpty()) {
                conn.setRequestProperty("Content-Type", "application/x-www-form-urlencoded; charset=UTF-8")
                val body = params.joinToString("&") { enc(it.first) + "=" + enc(it.second) }.toByteArray()
                conn.setFixedLengthStreamingMode(body.size)
                conn.outputStream.use { it.write(body) }
            } else {
                val b = "----tv" + UUID.randomUUID().toString().replace("-", "")
                conn.setRequestProperty("Content-Type", "multipart/form-data; boundary=$b")
                conn.setChunkedStreamingMode(0)
                DataOutputStream(conn.outputStream).use { o ->
                    for ((k, v) in params) {
                        o.writeBytes("--$b\r\nContent-Disposition: form-data; name=\"$k\"\r\n\r\n"); o.write(v.toByteArray()); o.writeBytes("\r\n")
                    }
                    for (f in files) {
                        var name = "file"; var mime = ctx.contentResolver.getType(f.uri) ?: "application/octet-stream"
                        ctx.contentResolver.query(f.uri, null, null, null, null)?.use { c ->
                            val i = c.getColumnIndex(OpenableColumns.DISPLAY_NAME); if (c.moveToFirst() && i >= 0) name = c.getString(i)
                        }
                        if (!name.contains('.')) name += when { mime.contains("pdf") -> ".pdf"; mime.contains("png") -> ".png"; mime.contains("webp") -> ".webp"; else -> ".jpg" }
                        o.writeBytes("--$b\r\nContent-Disposition: form-data; name=\"${f.field}\"; filename=\"${name.replace("\"", "")}\"\r\nContent-Type: $mime\r\n\r\n")
                        ctx.contentResolver.openInputStream(f.uri)?.use { it.copyTo(o) }
                        o.writeBytes("\r\n")
                    }
                    o.writeBytes("--$b--\r\n")
                }
            }
            val code = conn.responseCode
            val txt = (if (code >= 400) conn.errorStream else conn.inputStream)?.bufferedReader()?.readText() ?: ""
            return try { JSONObject(txt) } catch (e: Exception) { JSONObject().put("ok", false).put("error", S.t("badresp") + " ($code)") }
        } catch (e: Exception) {
            return JSONObject().put("ok", false).put("error", S.t("noconn")).put("net", true)
        } finally { conn?.disconnect() }
    }

    fun screen(id: String, p: Map<String, String>): JSONObject {
        val l = ArrayList<Pair<String, String>>(); l.add("screen" to id)
        for ((k, v) in p) l.add("p[$k]" to v)
        return call(l)
    }
    fun act(id: String, f: Map<String, String>, files: List<UploadFile>): JSONObject {
        val l = ArrayList<Pair<String, String>>(); l.add("act" to id)
        for ((k, v) in f) l.add("f[$k]" to v)
        return call(l, files)
    }
}
