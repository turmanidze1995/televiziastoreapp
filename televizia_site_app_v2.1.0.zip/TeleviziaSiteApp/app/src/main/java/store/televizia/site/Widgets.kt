package store.televizia.site

import android.content.Context
import android.graphics.Color
import android.graphics.Matrix
import android.graphics.drawable.Drawable
import android.graphics.Bitmap
import android.view.GestureDetector
import android.view.MotionEvent
import android.view.ScaleGestureDetector
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import androidx.viewpager.widget.PagerAdapter

/** სურათი გადიდებით: ორი თითით, ორმაგი შეხებით, გადაადგილება (ViewPager-ში სლაიდებს არ ბლოკავს, სანამ გადიდებული არ არის) */
class ZoomImageView(c: Context) : ImageView(c) {
    private val m = Matrix()
    private val vals = FloatArray(9)
    private var minS = 1f
    private var curS = 1f
    var onTap: (() -> Unit)? = null

    private val sd = ScaleGestureDetector(c, object : ScaleGestureDetector.SimpleOnScaleGestureListener() {
        override fun onScale(d: ScaleGestureDetector): Boolean {
            val target = (curS * d.scaleFactor).coerceIn(minS, minS * 5f)
            val f = target / curS
            m.postScale(f, f, d.focusX, d.focusY); curS = target; fix(); imageMatrix = m
            return true
        }
    })
    private val gd = GestureDetector(c, object : GestureDetector.SimpleOnGestureListener() {
        override fun onDown(e: MotionEvent): Boolean = true
        override fun onDoubleTap(e: MotionEvent): Boolean {
            val target = if (curS > minS * 1.1f) minS else minS * 2.5f
            val f = target / curS
            m.postScale(f, f, e.x, e.y); curS = target; fix(); imageMatrix = m
            return true
        }
        override fun onScroll(e1: MotionEvent?, e2: MotionEvent, dx: Float, dy: Float): Boolean {
            if (curS > minS * 1.01f) { m.postTranslate(-dx, -dy); fix(); imageMatrix = m; return true }
            return false
        }
        override fun onSingleTapConfirmed(e: MotionEvent): Boolean { onTap?.invoke(); return true }
    })

    init { scaleType = ScaleType.MATRIX; setBackgroundColor(Color.BLACK) }

    override fun setImageBitmap(bm: Bitmap?) { super.setImageBitmap(bm); post { reset() } }
    override fun setImageDrawable(d: Drawable?) { super.setImageDrawable(d); post { reset() } }
    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) { super.onSizeChanged(w, h, ow, oh); reset() }

    private fun reset() {
        val d = drawable ?: return
        if (width == 0 || height == 0 || d.intrinsicWidth <= 0 || d.intrinsicHeight <= 0) return
        val dw = d.intrinsicWidth.toFloat(); val dh = d.intrinsicHeight.toFloat()
        minS = Math.min(width / dw, height / dh)
        m.reset(); m.postScale(minS, minS); m.postTranslate((width - dw * minS) / 2f, (height - dh * minS) / 2f)
        curS = minS; imageMatrix = m
    }

    private fun fix() {
        val d = drawable ?: return
        m.getValues(vals)
        val w = d.intrinsicWidth * vals[Matrix.MSCALE_X]; val h = d.intrinsicHeight * vals[Matrix.MSCALE_Y]
        var tx = vals[Matrix.MTRANS_X]; var ty = vals[Matrix.MTRANS_Y]
        tx = if (w <= width) (width - w) / 2f else tx.coerceIn(width - w, 0f)
        ty = if (h <= height) (height - h) / 2f else ty.coerceIn(height - h, 0f)
        vals[Matrix.MTRANS_X] = tx; vals[Matrix.MTRANS_Y] = ty; m.setValues(vals)
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        sd.onTouchEvent(e); gd.onTouchEvent(e)
        parent?.requestDisallowInterceptTouchEvent(curS > minS * 1.01f || e.pointerCount > 1)
        return true
    }
}

/** ფოტოების გვერდები ViewPager-ისთვის: fit=true -> სრული სურათი (ჩამოუჭრელი); zoom=true -> გადიდებადი */
class ImagePagerAdapter(private val ctx: Context, private val urls: List<String>, private val zoom: Boolean, private val onClick: (Int) -> Unit) : PagerAdapter() {
    override fun getCount() = urls.size
    override fun isViewFromObject(v: View, o: Any) = v === o
    override fun instantiateItem(container: ViewGroup, pos: Int): Any {
        val iv: ImageView
        if (zoom) {
            val z = ZoomImageView(ctx); z.onTap = { onClick(pos) }; iv = z
        } else {
            iv = ImageView(ctx); iv.scaleType = ImageView.ScaleType.FIT_CENTER; iv.setBackgroundColor(Color.parseColor("#0B0F1F"))
            iv.setOnClickListener { onClick(pos) }
        }
        container.addView(iv, ViewGroup.LayoutParams(-1, -1))
        Img.load(iv, urls[pos], if (zoom) 2200 else 1200)
        return iv
    }
    override fun destroyItem(container: ViewGroup, pos: Int, o: Any) { container.removeView(o as View) }
}
