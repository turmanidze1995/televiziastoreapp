package store.televizia.site

/** აპლიკაციის საკუთარი ტექსტები: ka / ru / en (სერვერის ტექსტები სერვერზე ითარგმნება) */
object S {
    var lang = "ka"
    private val m = mapOf(
        "retry" to arrayOf("თავიდან ცდა", "Повторить", "Retry"),
        "error" to arrayOf("შეცდომა", "Ошибка", "Error"),
        "screen_fail" to arrayOf("ეკრანი ვერ ჩაიტვირთა", "Не удалось загрузить экран", "Could not load the screen"),
        "yes" to arrayOf("დიახ", "Да", "Yes"),
        "cancel" to arrayOf("გაუქმება", "Отмена", "Cancel"),
        "link_fail" to arrayOf("ბმული ვერ გაიხსნა", "Не удалось открыть ссылку", "Could not open the link"),
        "share" to arrayOf("გაზიარება", "Поделиться", "Share"),
        "copied" to arrayOf("დაკოპირდა", "Скопировано", "Copied"),
        "copy" to arrayOf("კოპირება", "Копировать", "Copy"),
        "no_file" to arrayOf("ფაილი არ არის არჩეული", "Файл не выбран", "No file selected"),
        "file_ok" to arrayOf("✔ არჩეულია", "✔ Выбрано", "✔ Selected"),
        "pick_file" to arrayOf("📎 ფაილის არჩევა", "📎 Выбрать файл", "📎 Choose a file"),
        "pick_receipt" to arrayOf("აირჩიეთ ქვითარი", "Выберите квитанцию", "Choose the receipt"),
        "login" to arrayOf("შესვლა", "Войти", "Sign in"),
        "register" to arrayOf("რეგისტრაცია", "Регистрация", "Register"),
        "lang_title" to arrayOf("ენა", "Язык", "Language"),
        "search_ch" to arrayOf("🔍 არხის ძებნა", "🔍 Поиск канала", "🔍 Search channels"),
        "show_more" to arrayOf("მეტის ჩვენება", "Показать ещё", "Show more"),
        "channels" to arrayOf("არხი", "каналов", "channels"),
        "nothing" to arrayOf("არხები ვერ მოიძებნა", "Каналы не найдены", "No channels found"),
        "no_loc" to arrayOf("მდებარეობა ვერ დადგინდა. ჩართეთ GPS და სცადეთ თავიდან.", "Не удалось определить местоположение. Включите GPS и повторите.", "Could not get your location. Turn on GPS and try again."),
        "locating" to arrayOf("ვადგენ მდებარეობას…", "Определяю местоположение…", "Finding your location…"),
        "close" to arrayOf("დახურვა", "Закрыть", "Close"),
        "play_fail" to arrayOf("ვიდეო ვერ ჩაირთო", "Не удалось включить видео", "Could not play the video"),
        "noconn" to arrayOf("კავშირის შეცდომა. შეამოწმეთ ინტერნეტი.", "Ошибка соединения. Проверьте интернет.", "Connection error. Check your internet."),
        "badresp" to arrayOf("სერვერის პასუხი არასწორია", "Неверный ответ сервера", "Invalid server response"),
        "back" to arrayOf("უკან", "Назад", "Back")
    )
    private fun idx() = when (lang) { "ru" -> 1; "en" -> 2; else -> 0 }
    fun t(k: String): String = m[k]?.get(idx()) ?: k
}
