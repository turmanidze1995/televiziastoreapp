package store.televizia.site

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.os.Handler
import android.os.Looper
import android.util.LruCache
import android.widget.ImageView
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.Executors

object Img {
    private val cache = object : LruCache<String, Bitmap>(32 * 1024 * 1024) { override fun sizeOf(k: String, v: Bitmap) = v.byteCount }
    private val pool = Executors.newFixedThreadPool(4)
    private val main = Handler(Looper.getMainLooper())

    fun load(iv: ImageView, url: String, maxPx: Int = 1400, onFail: (() -> Unit)? = null) {
        iv.tag = url
        if (url.isEmpty()) { onFail?.invoke(); return }
        cache.get(url)?.let { iv.setImageBitmap(it); return }
        pool.execute {
            try {
                val c = URL(url).openConnection() as HttpURLConnection
                c.connectTimeout = 10000; c.readTimeout = 20000
                c.setRequestProperty("User-Agent", "TeleviziaSiteApp")
                if (c.responseCode >= 400) throw Exception("http")
                val bytes = c.inputStream.use { it.readBytes() }
                val o = BitmapFactory.Options(); o.inJustDecodeBounds = true; BitmapFactory.decodeByteArray(bytes, 0, bytes.size, o)
                var s = 1; while (o.outWidth / (s * 2) >= maxPx) s *= 2
                val o2 = BitmapFactory.Options(); o2.inSampleSize = s
                val bmp = BitmapFactory.decodeByteArray(bytes, 0, bytes.size, o2) ?: throw Exception("decode")
                cache.put(url, bmp)
                main.post { if (iv.tag == url) iv.setImageBitmap(bmp) }
            } catch (e: Exception) { main.post { if (iv.tag == url) onFail?.invoke() } }
        }
    }
}
