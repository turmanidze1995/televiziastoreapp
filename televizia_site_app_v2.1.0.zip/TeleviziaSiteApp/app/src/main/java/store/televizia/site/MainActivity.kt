package store.televizia.site

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.app.Dialog
import android.view.WindowManager
import androidx.viewpager.widget.ViewPager
import android.location.LocationManager
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.InputMethodManager
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout
import org.json.JSONArray
import org.json.JSONObject

/** ნატიური (WebView-ის გარეშე) საიტის აპლიკაცია: სერვერი აბრუნებს ეკრანებს (ბლოკების სიას), აპლიკაცია ხატავს ნატიურ ელემენტებს */
class MainActivity : AppCompatActivity() {

    private val BG = Color.parseColor("#0B0E14"); private val BG2 = Color.parseColor("#131722"); private val CARD = Color.parseColor("#1A1F2E"); private val LINE = Color.parseColor("#262C3D")
    private val TXT = Color.parseColor("#F2F3F7"); private val MUTED = Color.parseColor("#9AA0B4"); private val ACC = Color.parseColor("#6C5CE7"); private val ACC2 = Color.parseColor("#00D9C0")
    private val RED = Color.parseColor("#E5484D"); private val GREEN = Color.parseColor("#2ECC71"); private val AMBER = Color.parseColor("#F5A524")

    private val main = Handler(Looper.getMainLooper())
    private class Frame(val id: String, val params: Map<String, String>)
    private val stacks = HashMap<String, ArrayList<Frame>>()
    private var tabs = JSONArray()
    private var tab = "home"
    private var site = "TELEVIZIA"

    private lateinit var title: TextView
    private lateinit var back: TextView
    private lateinit var tabBar: LinearLayout
    private lateinit var content: LinearLayout
    private lateinit var swipe: SwipeRefreshLayout
    private lateinit var banner: TextView
    private lateinit var topRight: LinearLayout
    private var loggedIn = false
    private var userName = ""
    private var pendingLocate = false
    private lateinit var progress: ProgressBar
    private var gen = 0                       // მოძველებული პასუხების გამოსარიცხად
    private var refreshRunnable: Runnable? = null
    private val fieldViews = ArrayList<() -> Boolean>()   // true = ველი შევსებულია (ავტო-განახლებას აჩერებს)

    // ფაილის არჩევა
    private var pickTarget: ((Uri) -> Unit)? = null
    private val REQ_PICK = 8801; private val REQ_LOC = 8802
    private var askedLoc = false

    private fun dp(v: Int) = (v * resources.displayMetrics.density + 0.5f).toInt()
    private fun bg(color: Int, r: Int = 12, stroke: Int = 0): GradientDrawable = GradientDrawable().apply {
        setColor(color); cornerRadius = dp(r).toFloat(); if (stroke != 0) setStroke(dp(1), stroke)
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        Api.init(this)
        buildShell()
        loadBoot()
    }

    // ---------------- გარსი ----------------
    private fun buildShell() {
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(BG) }
        val top = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setBackgroundColor(BG2); setPadding(dp(6), 0, dp(10), 0) }
        back = TextView(this).apply { text = "←"; textSize = 24f; setTextColor(TXT); gravity = Gravity.CENTER; setPadding(dp(10), 0, dp(10), 0); visibility = View.GONE; setOnClickListener { goBack() } }
        title = TextView(this).apply { textSize = 18f; setTextColor(TXT); typeface = Typeface.DEFAULT_BOLD; setPadding(dp(8), 0, dp(6), 0); maxLines = 1; ellipsize = android.text.TextUtils.TruncateAt.END }
        topRight = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        top.addView(back, LinearLayout.LayoutParams(-2, -1)); top.addView(title, LinearLayout.LayoutParams(0, -1, 1f)); top.addView(topRight, LinearLayout.LayoutParams(-2, -1))
        root.addView(top, LinearLayout.LayoutParams(-1, dp(56)))
        root.addView(View(this).apply { setBackgroundColor(LINE) }, LinearLayout.LayoutParams(-1, 1))

        val frame = FrameLayout(this)
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        banner = TextView(this).apply { textSize = 14f; setTextColor(Color.WHITE); setPadding(dp(14), dp(10), dp(14), dp(10)); visibility = View.GONE; setOnClickListener { visibility = View.GONE } }
        col.addView(banner, LinearLayout.LayoutParams(-1, -2))
        swipe = SwipeRefreshLayout(this)
        swipe.setColorSchemeColors(ACC, ACC2)
        val sv = ScrollView(this).apply { isFillViewport = true; clipToPadding = false }
        content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(14), dp(12), dp(14), dp(24)) }
        sv.addView(content, FrameLayout.LayoutParams(-1, -2))
        swipe.addView(sv)
        swipe.setOnRefreshListener { reload() }
        col.addView(swipe, LinearLayout.LayoutParams(-1, 0, 1f))
        frame.addView(col, FrameLayout.LayoutParams(-1, -1))
        progress = ProgressBar(this).apply { visibility = View.GONE }
        frame.addView(progress, FrameLayout.LayoutParams(dp(44), dp(44), Gravity.CENTER))
        root.addView(frame, LinearLayout.LayoutParams(-1, 0, 1f))

        root.addView(View(this).apply { setBackgroundColor(LINE) }, LinearLayout.LayoutParams(-1, 1))
        tabBar = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; setBackgroundColor(BG2); setPadding(dp(4), dp(4), dp(4), dp(4)) }
        root.addView(tabBar, LinearLayout.LayoutParams(-1, dp(62)))
        setContentView(root)
        buildTopRight()
    }

    /** ზედა პანელის მარჯვენა მხარე: ენა + (სტუმარი: შესვლა | მომხმარებელი: შეტყობინება + ავატარი) */
    private fun buildTopRight() {
        topRight.removeAllViews()
        val lang = TextView(this).apply {
            text = "🌐 " + S.lang.uppercase().let { if (it == "KA") "KA" else it }; textSize = 12f; setTextColor(TXT); typeface = Typeface.DEFAULT_BOLD; gravity = Gravity.CENTER
            background = bg(CARD, 16, LINE); setPadding(dp(10), dp(6), dp(10), dp(6)); setOnClickListener { showLangDialog() }
        }
        topRight.addView(lang, LinearLayout.LayoutParams(-2, -2).apply { setMargins(0, 0, dp(8), 0) })
        if (!loggedIn) {
            val pill = TextView(this).apply {
                text = S.t("login"); textSize = 13f; setTextColor(Color.WHITE); typeface = Typeface.DEFAULT_BOLD; gravity = Gravity.CENTER; setPadding(dp(14), dp(7), dp(14), dp(7))
                background = GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, intArrayOf(ACC, Color.parseColor("#4B3FC7"))).apply { cornerRadius = dp(16).toFloat() }
                setOnClickListener { perform(JSONObject().put("a", "root").put("id", "login")) }
            }
            topRight.addView(pill, LinearLayout.LayoutParams(-2, -2).apply { setMargins(0, 0, dp(6), 0) })
            val reg = TextView(this).apply {
                text = S.t("register"); textSize = 13f; setTextColor(ACC2); typeface = Typeface.DEFAULT_BOLD; gravity = Gravity.CENTER; setPadding(dp(12), dp(7), dp(12), dp(7))
                background = bg(Color.TRANSPARENT, 16, ACC2); setOnClickListener { perform(JSONObject().put("a", "root").put("id", "register")) }
            }
            topRight.addView(reg)
        } else {
            val bell = TextView(this).apply { text = "🔔"; textSize = 18f; gravity = Gravity.CENTER; setPadding(dp(8), 0, dp(8), 0); setOnClickListener { perform(JSONObject().put("a", "screen").put("id", "notifications")) } }
            topRight.addView(bell, LinearLayout.LayoutParams(-2, -2))
            val av = TextView(this).apply {
                text = userName.trim().take(1).uppercase().ifEmpty { "👤" }; textSize = 15f; setTextColor(Color.WHITE); typeface = Typeface.DEFAULT_BOLD; gravity = Gravity.CENTER
                background = GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(ACC, ACC2)).apply { shape = GradientDrawable.OVAL }
                setOnClickListener { selectTab("account") }
            }
            topRight.addView(av, LinearLayout.LayoutParams(dp(34), dp(34)))
        }
    }

    private fun showLangDialog() {
        val names = arrayOf("ქართული", "English", "Русский"); val codes = arrayOf("ka", "en", "ru")
        AlertDialog.Builder(this).setTitle("🌐 " + S.t("lang_title")).setSingleChoiceItems(names, codes.indexOf(S.lang)) { d, i ->
            d.dismiss()
            if (codes[i] != S.lang) {
                Api.lang = codes[i]
                for (k in stacks.keys) stacks[k] = arrayListOf()
                content.removeAllViews(); buildTopRight(); loadBoot()
            }
        }.show()
    }

    private fun buildTabs() {
        tabBar.removeAllViews()
        for (i in 0 until tabs.length()) {
            val t = tabs.getJSONObject(i); val id = t.getString("id"); val on = id == tab
            val v = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER; setOnClickListener { selectTab(id) }
                if (on) background = bg(Color.argb(46, 108, 92, 231), 14, Color.argb(120, 108, 92, 231)) }
            v.addView(TextView(this).apply { text = t.optString("icon"); textSize = if (on) 22f else 20f; gravity = Gravity.CENTER })
            v.addView(TextView(this).apply { text = t.optString("label"); textSize = 10.5f; gravity = Gravity.CENTER; maxLines = 1; setTextColor(if (on) ACC2 else MUTED); if (on) typeface = Typeface.DEFAULT_BOLD })
            tabBar.addView(v, LinearLayout.LayoutParams(0, -1, 1f).apply { setMargins(dp(2), 0, dp(2), 0) })
        }
    }

    private fun loadBoot() {
        progress.visibility = View.VISIBLE
        Thread {
            val r = Api.screen("boot", emptyMap())
            main.post {
                progress.visibility = View.GONE
                if (r.optBoolean("ok") && r.has("tabs")) {
                    tabs = r.getJSONArray("tabs"); site = r.optString("site", site); loggedIn = r.optBoolean("logged_in"); userName = r.optString("user"); buildTopRight()
                    if (stacks.isEmpty()) for (i in 0 until tabs.length()) stacks[tabs.getJSONObject(i).getString("id")] = arrayListOf()
                    buildTabs(); selectTab(tab)
                } else showError(r.optString("error", S.t("error"))) { loadBoot() }
            }
        }.start()
    }

    private fun selectTab(id: String) {
        tab = id; buildTabs()
        val st = stacks.getOrPut(id) { arrayListOf() }
        if (st.isEmpty()) st.add(Frame(id, emptyMap()))
        reload()
    }

    private fun cur(): Frame? = stacks[tab]?.lastOrNull()
    private fun goBack() { val st = stacks[tab] ?: return; if (st.size > 1) { st.removeAt(st.size - 1); reload() } }
    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        val st = stacks[tab]
        if (st != null && st.size > 1) goBack()
        else if (tab != "home") selectTab("home")
        else super.onBackPressed()
    }

    // ---------------- ეკრანის ჩატვირთვა ----------------
    private fun reload() {
        val f = cur() ?: return
        val my = ++gen
        refreshRunnable?.let { main.removeCallbacks(it) }
        banner.visibility = View.GONE
        var p = f.params
        if (f.id == "weather" && !p.containsKey("lat") && !p.containsKey("c")) { val l = lastLocation(); if (l != null) p = p + mapOf("lat" to l.first.toString(), "lon" to l.second.toString()) }
        if (!swipe.isRefreshing && content.childCount == 0) progress.visibility = View.VISIBLE
        Thread {
            val r = Api.screen(f.id, p)
            main.post {
                if (my != gen) return@post
                progress.visibility = View.GONE; swipe.isRefreshing = false
                render(f, r)
            }
        }.start()
    }

    private fun showError(msg: String, retry: (() -> Unit)?) {
        content.removeAllViews()
        content.addView(TextView(this).apply { text = "⚠️ $msg"; setTextColor(TXT); textSize = 16f; gravity = Gravity.CENTER; setPadding(0, dp(40), 0, dp(16)) })
        if (retry != null) content.addView(button(S.t("retry"), "primary") { retry() })
    }

    private fun render(f: Frame, r: JSONObject) {
        content.removeAllViews(); fieldViews.clear()
        val st = stacks[tab]!!
        back.visibility = if (st.size > 1) View.VISIBLE else View.GONE
        if (!r.optBoolean("ok", true) || !r.has("blocks")) { title.text = site; showError(r.optString("error", S.t("screen_fail"))) { reload() }; return }
        title.text = if (st.size > 1 || f.id != tab) r.optString("title", site) else site
        val blocks = r.getJSONArray("blocks")
        for (i in 0 until blocks.length()) addBlock(content, blocks.getJSONObject(i))
        val rf = r.optInt("refresh", 0)
        if (rf > 0) {
            val run = Runnable { if (fieldViews.none { it() }) reload() else refreshRunnable?.let { main.postDelayed(it, rf * 1000L) } }
            refreshRunnable = run; main.postDelayed(run, rf * 1000L)
        }
        if (r.optBoolean("wants_location") && !askedLoc && !hasLoc()) { askedLoc = true; ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION), REQ_LOC) }
    }

    // ---------------- მოქმედებები ----------------
    private fun perform(a: JSONObject?) {
        if (a == null) return
        when (a.optString("a")) {
            "screen" -> { stacks[tab]!!.add(Frame(a.getString("id"), params(a.optJSONObject("p")))); reload() }
            "replace" -> { val st = stacks[tab]!!; if (st.isNotEmpty()) st.removeAt(st.size - 1); st.add(Frame(a.getString("id"), params(a.optJSONObject("p")))); reload() }
            "root" -> {
                val id = a.getString("id"); val p = params(a.optJSONObject("p"))
                val target = if (isTab(id)) id else if (id == "login" || id == "register") "account" else tab
                stacks[target] = arrayListOf(Frame(if (isTab(id)) id else target, emptyMap()))
                if (!isTab(id)) stacks[target]!!.add(Frame(id, p))
                tab = target; buildTabs(); reload()
            }
            "back" -> goBack()
            "lang" -> showLangDialog()
            "locate" -> locateAndReload()
            "act" -> {
                val f = HashMap<String, String>(); a.optJSONObject("f")?.let { o -> o.keys().forEach { k -> f[k] = o.optString(k) } }
                val go = { doAct(a.getString("id"), f, emptyList(), null) }
                val c = a.optString("confirm")
                if (c.isNotEmpty()) AlertDialog.Builder(this).setMessage(c).setPositiveButton(S.t("yes")) { _, _ -> go() }.setNegativeButton(S.t("cancel"), null).show() else go()
            }
            "url" -> try { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(a.getString("url")))) } catch (e: Exception) { toast(S.t("link_fail")) }
            "copy" -> { (getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager).setPrimaryClip(ClipData.newPlainText("t", a.optString("text"))); toast(a.optString("toast", S.t("copied"))) }
            "share" -> startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, a.optString("text")), S.t("share")))
            "app" -> {
                val i = packageManager.getLaunchIntentForPackage(a.optString("pkg"))
                try { if (i != null) startActivity(i) else if (a.optString("url").isNotEmpty()) startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(a.optString("url")))) } catch (e: Exception) { }
            }
        }
    }
    private fun isTab(id: String): Boolean { for (i in 0 until tabs.length()) if (tabs.getJSONObject(i).getString("id") == id) return true; return false }
    private fun params(o: JSONObject?): Map<String, String> { val m = HashMap<String, String>(); o?.keys()?.forEach { k -> m[k] = o.optString(k) }; return m }

    private fun doAct(id: String, f: Map<String, String>, files: List<UploadFile>, done: (() -> Unit)?) {
        progress.visibility = View.VISIBLE
        Thread {
            val r = Api.act(id, f, files)
            main.post {
                progress.visibility = View.GONE; done?.invoke()
                if (r.optString("token").isNotEmpty()) { Api.token = r.getString("token") }
                if (r.optBoolean("logout")) { Api.token = ""; }
                if (r.optBoolean("ok")) {
                    if (r.optString("toast").isNotEmpty()) say(r.getString("toast"), true)
                    if (r.optString("token").isNotEmpty() || r.optBoolean("logout")) {
                        // ტაბების სახელები (შესვლა/ანგარიში) განახლდეს
                        val nav = r.optJSONObject("nav")
                        for (k in stacks.keys) stacks[k] = arrayListOf()
                        Thread { val b = Api.screen("boot", emptyMap()); main.post { if (b.has("tabs")) { tabs = b.getJSONArray("tabs"); loggedIn = b.optBoolean("logged_in"); userName = b.optString("user"); buildTopRight() }; buildTabs(); if (nav != null) perform(nav) else selectTab("home") } }.start()
                    } else if (r.optJSONObject("nav") != null) perform(r.optJSONObject("nav")) else if (id.endsWith("_send") || id.endsWith("_check")) { /* ფორმა რჩება */ }
                } else say(r.optString("error", S.t("error")), false)
            }
        }.start()
    }

    private fun say(msg: String, ok: Boolean) {
        banner.text = msg; banner.setBackgroundColor(if (ok) Color.parseColor("#1E7F4F") else Color.parseColor("#9B2C30")); banner.visibility = View.VISIBLE
        main.postDelayed({ if (banner.text == msg) banner.visibility = View.GONE }, if (ok) 4000 else 7000)
    }
    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()

    // ---------------- ბლოკები ----------------
    private fun lp(top: Int = 0, bottom: Int = 10) = LinearLayout.LayoutParams(-1, -2).apply { setMargins(0, dp(top), 0, dp(bottom)) }
    private fun tv(text: String, size: Float, color: Int = TXT, bold: Boolean = false) = TextView(this).apply {
        this.text = text; textSize = size; setTextColor(color); if (bold) typeface = Typeface.DEFAULT_BOLD; setLineSpacing(0f, 1.15f)
    }
    private fun button(label: String, style: String, onClick: () -> Unit) = Button(this).apply {
        text = label; isAllCaps = false; textSize = 15f; setTextColor(TXT); typeface = Typeface.DEFAULT_BOLD
        stateListAnimator = null
        background = when (style) {
            "secondary" -> framedBg(12)
            "danger" -> bg(RED, 12)
            else -> GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, intArrayOf(ACC, Color.parseColor("#3D8BE8"))).apply { cornerRadius = dp(12).toFloat() }
        }
        setPadding(dp(14), dp(12), dp(14), dp(12)); layoutParams = lp(0, 10); setOnClickListener { onClick() }
    }

    /** საიტის „გრადიენტული ჩარჩო“: იისფერი→ცისფერი კონტური + მუქი ბარათი. padding დააყენეთ ფონის შემდეგ! */
    private fun framedBg(r: Int = 16): android.graphics.drawable.Drawable {
        val outer = GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(Color.argb(190, 108, 92, 231), Color.argb(190, 0, 217, 192))).apply { cornerRadius = dp(r).toFloat() }
        val inner = GradientDrawable().apply { setColor(CARD); cornerRadius = dp(r - 2).toFloat() }
        return android.graphics.drawable.LayerDrawable(arrayOf(outer, inner)).apply { setLayerInset(1, dp(2), dp(2), dp(2), dp(2)) }
    }
    private fun roundClip(v: View, r: Int) {
        v.outlineProvider = object : android.view.ViewOutlineProvider() {
            override fun getOutline(view: View, o: android.graphics.Outline) { o.setRoundRect(0, 0, view.width, view.height, dp(r).toFloat()) }
        }
        v.clipToOutline = true
    }

    private fun addBlock(parent: LinearLayout, b: JSONObject) {
        when (b.optString("t")) {
            "hero" -> parent.addView(LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL; background = GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(ACC, Color.parseColor("#2A9FB8"))).apply { cornerRadius = dp(18).toFloat() }
                setPadding(dp(18), dp(20), dp(18), dp(20)); addView(tv(b.optString("title"), 22f, Color.WHITE, true))
                if (b.optString("sub").isNotEmpty()) addView(tv(b.optString("sub"), 14f, Color.parseColor("#E6F6FF")).apply { setPadding(0, dp(6), 0, 0) })
            }, lp(0, 14))
            "text" -> {
                val s = b.optString("style")
                parent.addView(when (s) {
                    "h1" -> tv(b.optString("text"), 21f, TXT, true); "h2" -> tv(b.optString("text"), 17f, TXT, true).apply { setPadding(0, dp(8), 0, 0) }
                    "muted" -> tv(b.optString("text"), 13f, MUTED); "small" -> tv(b.optString("text"), 12f, MUTED)
                    "center" -> tv(b.optString("text"), 15f).apply { gravity = Gravity.CENTER }
                    else -> tv(b.optString("text"), 15f, Color.parseColor("#DDE1EE")) }, lp(0, 10))
            }
            "button" -> { val act = b.optJSONObject("action"); parent.addView(button(b.optString("label"), b.optString("style")) { perform(act) }) }
            "notice" -> {
                val c = when (b.optString("kind")) { "ok" -> GREEN; "warn" -> AMBER; "error" -> RED; else -> ACC2 }
                parent.addView(tv(b.optString("text"), 14f).apply { background = bg(Color.argb(40, Color.red(c), Color.green(c), Color.blue(c)), 12, c); setPadding(dp(14), dp(12), dp(14), dp(12)) }, lp(0, 12))
            }
            "card" -> addCard(parent, b)
            "kv" -> {
                val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; background = framedBg(16); setPadding(dp(16), dp(12), dp(16), dp(12)) }
                if (b.optString("title").isNotEmpty()) box.addView(tv(b.optString("title"), 15f, TXT, true).apply { setPadding(0, 0, 0, dp(6)) })
                val rows = b.optJSONArray("rows") ?: JSONArray()
                for (i in 0 until rows.length()) { val r = rows.getJSONArray(i)
                    box.addView(LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; setPadding(0, dp(5), 0, dp(5))
                        addView(tv(r.optString(0), 14f, MUTED), LinearLayout.LayoutParams(0, -2, 1f)); addView(tv(r.optString(1), 14f, TXT, true).apply { gravity = Gravity.END }, LinearLayout.LayoutParams(0, -2, 1.2f)) }) }
                parent.addView(box, lp(0, 12))
            }
            "list" -> {
                if (b.optString("title").isNotEmpty()) parent.addView(tv(b.optString("title"), 15f, ACC2, true), lp(6, 6))
                val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; background = framedBg(16); setPadding(dp(2), dp(2), dp(2), dp(2)) }
                val items = b.optJSONArray("items") ?: JSONArray()
                for (i in 0 until items.length()) {
                    val it = items.getJSONObject(i)
                    val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(dp(14), dp(13), dp(14), dp(13)) }
                    val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
                    col.addView(tv(it.optString("title"), 15f)); if (it.optString("sub").isNotEmpty()) col.addView(tv(it.optString("sub"), 12.5f, MUTED))
                    row.addView(col, LinearLayout.LayoutParams(0, -2, 1f))
                    if (it.optString("right").isNotEmpty()) row.addView(tv(it.optString("right"), 14f, ACC2, true))
                    val act = it.optJSONObject("action"); if (act != null) { row.addView(tv("›", 22f, MUTED).apply { setPadding(dp(8), 0, 0, 0) }); row.setOnClickListener { perform(act) } }
                    box.addView(row)
                    if (i < items.length() - 1) box.addView(View(this).apply { setBackgroundColor(LINE) }, LinearLayout.LayoutParams(-1, 1))
                }
                parent.addView(box, lp(0, 12))
            }
            "image" -> { val u = b.optString("url"); parent.addView(ImageView(this).apply { scaleType = ImageView.ScaleType.FIT_CENTER; adjustViewBounds = true; background = bg(Color.parseColor("#0B0F1F"), 12); Img.load(this, u); setOnClickListener { openViewer(listOf(u), 0) } }, lp(0, 12)) }
            "gallery" -> parent.addView(makeGallery(strList(b.optJSONArray("images")), b.optDouble("ratio", 0.75).toFloat()), lp(0, 12))
            "video" -> addVideo(parent, b)
            "channels" -> addChannels(parent, b.getJSONArray("items"))
            "weather_hero" -> addWeatherHero(parent, b)
            "grid" -> addGrid(parent, b)
            "hscroll" -> {
                val hs = HorizontalScrollView(this).apply { isHorizontalScrollBarEnabled = false }
                val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; setPadding(dp(6), dp(10), dp(6), dp(10)) }
                val items = b.optJSONArray("items") ?: JSONArray()
                for (i in 0 until items.length()) { val it = items.getJSONObject(i)
                    row.addView(LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER; setPadding(dp(10), 0, dp(10), 0)
                        addView(tv(it.optString("time"), 12f, MUTED).apply { gravity = Gravity.CENTER }); addView(tv(it.optString("icon"), 24f).apply { gravity = Gravity.CENTER })
                        addView(tv(it.optString("temp"), 15f, TXT, true).apply { gravity = Gravity.CENTER }); addView(tv(it.optString("pop"), 11f, MUTED).apply { gravity = Gravity.CENTER }) }, LinearLayout.LayoutParams(dp(62), -2)) }
                hs.addView(row)
                val box = FrameLayout(this).apply { background = framedBg(16); setPadding(dp(2), dp(2), dp(2), dp(2)) }; box.addView(hs)
                parent.addView(box, lp(0, 12))
            }
            "dayrows" -> {
                val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; background = framedBg(16); setPadding(dp(2), dp(2), dp(2), dp(2)) }
                val items = b.optJSONArray("items") ?: JSONArray()
                for (i in 0 until items.length()) { val it = items.getJSONObject(i)
                    val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(dp(12), dp(10), dp(10), dp(10)) }
                    val c1 = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }; c1.addView(tv(it.optString("day"), 15f, TXT, true)); c1.addView(tv(it.optString("date"), 11.5f, MUTED))
                    val c2 = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER }; c2.addView(tv(it.optString("icon"), 22f).apply { gravity = Gravity.CENTER }); c2.addView(tv(it.optString("text"), 10.5f, MUTED).apply { gravity = Gravity.CENTER })
                    val c4 = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.END }; c4.addView(tv(it.optString("hi"), 16f, TXT, true).apply { gravity = Gravity.END }); c4.addView(tv(it.optString("lo"), 13f, MUTED).apply { gravity = Gravity.END })
                    row.addView(c1, LinearLayout.LayoutParams(0, -2, 1f)); row.addView(c2, LinearLayout.LayoutParams(0, -2, 1.4f)); row.addView(tv(it.optString("pop"), 12f, ACC2), LinearLayout.LayoutParams(dp(50), -2)); row.addView(c4, LinearLayout.LayoutParams(dp(46), -2))
                    row.addView(tv("›", 20f, MUTED).apply { setPadding(dp(6), 0, 0, 0) })
                    val act = it.optJSONObject("action"); if (act != null) row.setOnClickListener { perform(act) }
                    box.addView(row); if (i < items.length() - 1) box.addView(View(this).apply { setBackgroundColor(LINE) }, LinearLayout.LayoutParams(-1, 1))
                }
                parent.addView(box, lp(0, 12))
            }
            "bars" -> {
                val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; background = framedBg(16); setPadding(dp(14), dp(10), dp(14), dp(10)) }
                val items = b.optJSONArray("items") ?: JSONArray()
                for (i in 0 until items.length()) { val it = items.getJSONObject(i)
                    val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(0, dp(6), 0, dp(6)) }
                    val l = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }; l.addView(tv(it.optString("label"), 13f)); l.addView(tv(it.optString("sub"), 10.5f, MUTED))
                    val pct = it.optInt("pct", 0).coerceIn(2, 100); val col = when (it.optString("level")) { "hi" -> RED; "mid" -> AMBER; else -> GREEN }
                    val track = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; background = bg(Color.parseColor("#0E1220"), 6) }
                    track.addView(View(this).apply { background = bg(col, 6) }, LinearLayout.LayoutParams(0, dp(9), pct.toFloat())); track.addView(View(this), LinearLayout.LayoutParams(0, dp(9), (100 - pct).toFloat()))
                    row.addView(l, LinearLayout.LayoutParams(dp(92), -2)); row.addView(track, LinearLayout.LayoutParams(0, dp(9), 1f)); row.addView(tv(it.optString("text"), 12.5f, TXT, true).apply { gravity = Gravity.END }, LinearLayout.LayoutParams(dp(78), -2))
                    box.addView(row)
                }
                parent.addView(box, lp(0, 12))
            }
            "copyfield" -> {
                val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; background = bg(CARD, 12, ACC); setPadding(dp(14), dp(10), dp(14), dp(10)) }
                box.addView(tv(b.optString("label"), 12f, MUTED)); box.addView(tv(b.optString("value"), 14f, TXT, true).apply { setTextIsSelectable(true) })
                box.addView(tv(S.t("copy"), 13f, ACC2, true).apply { setPadding(0, dp(6), 0, 0); setOnClickListener { perform(JSONObject().put("a", "copy").put("text", b.optString("value"))) } })
                parent.addView(box, lp(0, 10))
            }
            "qr" -> parent.addView(tv(b.optString("value"), 13f, MUTED), lp(0, 10))
            "divider" -> parent.addView(View(this).apply { setBackgroundColor(LINE) }, LinearLayout.LayoutParams(-1, 1).apply { setMargins(0, dp(8), 0, dp(8)) })
            "spacer" -> parent.addView(View(this), LinearLayout.LayoutParams(-1, dp(b.optInt("h", 12))))
            "chips" -> {
                val hs = HorizontalScrollView(this).apply { isHorizontalScrollBarEnabled = false }
                val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
                val items = b.optJSONArray("items") ?: JSONArray()
                for (i in 0 until items.length()) { val it = items.getJSONObject(i); val act = it.optJSONObject("action")
                    row.addView(tv(it.optString("label"), 14f).apply { background = bg(CARD, 20, LINE); setPadding(dp(14), dp(8), dp(14), dp(8)); setOnClickListener { perform(act) } }, LinearLayout.LayoutParams(-2, -2).apply { setMargins(0, 0, dp(8), 0) }) }
                hs.addView(row); parent.addView(hs, lp(0, 12))
            }
            "bubble" -> {
                val mine = b.optBoolean("mine")
                val bub = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; background = if (mine) GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(ACC, Color.parseColor("#4B3FC7"))).apply { cornerRadius = dp(16).toFloat() } else bg(CARD, 16, LINE); setPadding(dp(12), dp(8), dp(12), dp(8)) }
                bub.addView(tv(b.optString("text"), 14.5f)); if (b.optString("time").isNotEmpty()) bub.addView(tv(b.optString("time"), 11f, if (mine) Color.parseColor("#DAD6FF") else MUTED))
                parent.addView(bub, LinearLayout.LayoutParams(-2, -2).apply { gravity = if (mine) Gravity.END else Gravity.START; setMargins(if (mine) dp(48) else 0, dp(2), if (mine) 0 else dp(30), dp(6)) })
            }
            "form" -> addForm(parent, b)
        }
    }

    private fun strList(a: JSONArray?): List<String> { val l = ArrayList<String>(); if (a != null) for (i in 0 until a.length()) l.add(a.optString(i)); return l }

    // ---------- ბარათი (ფოტო-გალერეით) ----------
    private fun addCard(parent: LinearLayout, b: JSONObject) {
        val urls = strList(b.optJSONArray("images"))
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; background = framedBg(16); setPadding(dp(2), dp(2), dp(2), dp(2)) }
        if (urls.isNotEmpty()) box.addView(makeGallery(urls, b.optDouble("ratio", 0.75).toFloat()), LinearLayout.LayoutParams(-1, -2))
        else if (b.optString("image").isNotEmpty()) {
            val fit = b.optBoolean("fit")
            box.addView(ImageView(this).apply { scaleType = if (fit) ImageView.ScaleType.FIT_CENTER else ImageView.ScaleType.CENTER_CROP; setBackgroundColor(Color.parseColor("#0B0F1F")); Img.load(this, b.getString("image")) }, LinearLayout.LayoutParams(-1, dp(if (fit) 200 else 170)))
        }
        val inner = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(14), dp(12), dp(14), dp(12)) }
        val head = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        head.addView(tv(b.optString("title"), 16f, TXT, true), LinearLayout.LayoutParams(0, -2, 1f))
        if (b.optString("price").isNotEmpty()) {
            val pc = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.END }
            pc.addView(tv(b.optString("price"), 17f, ACC2, true).apply { gravity = Gravity.END })
            if (b.optString("old_price").isNotEmpty()) pc.addView(tv(b.optString("old_price"), 12f, MUTED).apply { paintFlags = paintFlags or android.graphics.Paint.STRIKE_THRU_TEXT_FLAG; gravity = Gravity.END })
            head.addView(pc)
        }
        inner.addView(head)
        val lines = b.optJSONArray("lines"); if (lines != null) for (i in 0 until lines.length()) { val l = lines.optString(i); if (l.isNotEmpty()) inner.addView(tv(l, 13.5f, MUTED).apply { setPadding(0, dp(4), 0, 0) }) }
        if (b.optString("badge").isNotEmpty()) inner.addView(tv(b.optString("badge"), 12f, ACC2, true).apply { setPadding(0, dp(8), 0, 0) })
        box.addView(inner)
        val act = b.optJSONObject("action"); if (act != null) { inner.setOnClickListener { perform(act) }; if (urls.isEmpty()) box.setOnClickListener { perform(act) } }
        roundClip(box, 16)
        parent.addView(box, lp(0, 12))
    }

    // ---------- გალერეა: სლაიდშოუ (გადაფურცლვა) + შეხებით გადიდება ----------
    private fun makeGallery(urls: List<String>, ratio: Float): View {
        val w = resources.displayMetrics.widthPixels - dp(32)
        val h = Math.min((w / ratio).toInt(), dp(460))
        val wrap = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(Color.parseColor("#0B0F1F")) }
        val pager = ViewPager(this); pager.id = View.generateViewId()
        pager.adapter = ImagePagerAdapter(this, urls, false) { pos -> openViewer(urls, pos) }
        wrap.addView(pager, LinearLayout.LayoutParams(-1, h))
        if (urls.size > 1) {
            val dots = TextView(this).apply { gravity = Gravity.CENTER; textSize = 13f; setTextColor(ACC2); setPadding(0, dp(4), 0, dp(4)) }
            val upd = { p: Int -> dots.text = (0 until urls.size).joinToString(" ") { if (it == p) "●" else "○" } }
            upd(0)
            pager.addOnPageChangeListener(object : ViewPager.SimpleOnPageChangeListener() { override fun onPageSelected(position: Int) { upd(position) } })
            wrap.addView(dots, LinearLayout.LayoutParams(-1, -2))
        }
        return wrap
    }

    private fun openViewer(urls: List<String>, start: Int) {
        val d = Dialog(this, android.R.style.Theme_Black_NoTitleBar_Fullscreen)
        val fl = FrameLayout(this).apply { setBackgroundColor(Color.BLACK) }
        val pager = ViewPager(this); pager.id = View.generateViewId()
        pager.adapter = ImagePagerAdapter(this, urls, true) { }
        pager.currentItem = start
        fl.addView(pager, FrameLayout.LayoutParams(-1, -1))
        val cnt = TextView(this).apply { setTextColor(Color.WHITE); textSize = 15f; setPadding(dp(16), dp(18), dp(16), dp(8)); text = if (urls.size > 1) "${start + 1} / ${urls.size}" else "" }
        fl.addView(cnt, FrameLayout.LayoutParams(-2, -2, Gravity.TOP or Gravity.START))
        pager.addOnPageChangeListener(object : ViewPager.SimpleOnPageChangeListener() { override fun onPageSelected(position: Int) { cnt.text = "${position + 1} / ${urls.size}" } })
        val x = TextView(this).apply { text = "✕"; textSize = 26f; setTextColor(Color.WHITE); gravity = Gravity.CENTER; setPadding(dp(16), dp(10), dp(16), dp(10)); setOnClickListener { d.dismiss() } }
        fl.addView(x, FrameLayout.LayoutParams(-2, -2, Gravity.TOP or Gravity.END))
        d.setContentView(fl); d.show()
    }

    // ---------- ვიდეო ----------
    private fun addVideo(parent: LinearLayout, b: JSONObject) {
        val url = b.optString("url"); val kind = b.optString("kind"); val thumb = b.optString("thumb"); val ttl = b.optString("title")
        val w = resources.displayMetrics.widthPixels - dp(28)
        val h = if (ttl.isNotEmpty()) (w * 0.5f).toInt() else (w * 9f / 16f).toInt()
        val box = FrameLayout(this).apply { setBackgroundColor(Color.parseColor("#0B0F1F")); setOnClickListener { playVideo(url, kind) } }
        val iv = ImageView(this).apply { scaleType = ImageView.ScaleType.CENTER_CROP }
        box.addView(iv, FrameLayout.LayoutParams(-1, -1))
        if (thumb.isNotEmpty()) Img.load(iv, thumb, 900)
        box.addView(TextView(this).apply { text = "▶"; textSize = 24f; setTextColor(Color.WHITE); gravity = Gravity.CENTER; background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(Color.argb(215, 229, 72, 77)) } }, FrameLayout.LayoutParams(dp(60), dp(60), Gravity.CENTER))
        if (ttl.isNotEmpty()) box.addView(tv(ttl, 13f).apply { setBackgroundColor(Color.argb(160, 0, 0, 0)); setPadding(dp(10), dp(6), dp(10), dp(6)); maxLines = 2 }, FrameLayout.LayoutParams(-1, -2, Gravity.BOTTOM))
        roundClip(box, 14)
        parent.addView(box, LinearLayout.LayoutParams(-1, h).apply { setMargins(0, 0, 0, dp(12)) })
    }

    private fun playVideo(url: String, kind: String) {
        if (kind == "file") {
            val d = Dialog(this, android.R.style.Theme_Black_NoTitleBar_Fullscreen)
            val fl = FrameLayout(this).apply { setBackgroundColor(Color.BLACK) }
            val vv = VideoView(this)
            fl.addView(vv, FrameLayout.LayoutParams(-1, -1, Gravity.CENTER))
            val mc = MediaController(this); mc.setAnchorView(vv); vv.setMediaController(mc)
            vv.setOnErrorListener { _, _, _ -> toast(S.t("play_fail")); d.dismiss(); true }
            vv.setVideoURI(Uri.parse(url)); vv.setOnPreparedListener { it.start() }
            val x = TextView(this).apply { text = "✕"; textSize = 26f; setTextColor(Color.WHITE); setPadding(dp(16), dp(10), dp(16), dp(10)); setOnClickListener { d.dismiss() } }
            fl.addView(x, FrameLayout.LayoutParams(-2, -2, Gravity.TOP or Gravity.END))
            d.setOnDismissListener { try { vv.stopPlayback() } catch (e: Exception) { } }
            d.setContentView(fl); d.show()
        } else perform(JSONObject().put("a", "url").put("url", url))
    }

    // ---------- არხების სია: ნომერი + ლოგო + სახელი (საიტის მსგავსად) ----------
    private fun addChannels(parent: LinearLayout, items: JSONArray) {
        val all = ArrayList<JSONObject>(); for (i in 0 until items.length()) all.add(items.getJSONObject(i))
        val search = EditText(this).apply {
            hint = S.t("search_ch"); setHintTextColor(Color.parseColor("#59638C")); setTextColor(TXT); textSize = 15f
            background = bg(CARD, 12, LINE); setPadding(dp(12), dp(10), dp(12), dp(10)); inputType = InputType.TYPE_CLASS_TEXT; isSingleLine = true
        }
        parent.addView(search, lp(0, 10))
        val countTv = tv("", 13f, MUTED); parent.addView(countTv, lp(0, 6))
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; background = framedBg(16); setPadding(dp(2), dp(2), dp(2), dp(2)) }
        parent.addView(box, lp(0, 8))
        val more = button(S.t("show_more"), "secondary") { }
        parent.addView(more)
        var list: List<JSONObject> = all; var shown = 0; val page = 60
        fun addRows() {
            val end = Math.min(list.size, shown + page)
            for (i in shown until end) box.addView(channelRow(list[i]))
            shown = end
            more.visibility = if (shown < list.size) View.VISIBLE else View.GONE
        }
        fun rebuild() {
            box.removeAllViews(); shown = 0; countTv.text = "${list.size} " + S.t("channels")
            if (list.isEmpty()) box.addView(tv(S.t("nothing"), 14f, MUTED).apply { setPadding(dp(14), dp(14), dp(14), dp(14)) })
            addRows()
        }
        more.setOnClickListener { addRows() }
        search.addTextChangedListener(object : android.text.TextWatcher {
            override fun afterTextChanged(e: android.text.Editable?) {
                val q = (e?.toString() ?: "").trim().lowercase()
                list = if (q.isEmpty()) all else all.filter { it.optString("name").lowercase().contains(q) }
                rebuild()
            }
            override fun beforeTextChanged(s: CharSequence?, st: Int, c: Int, a: Int) {}
            override fun onTextChanged(s: CharSequence?, st: Int, b: Int, c: Int) {}
        })
        rebuild()
    }

    private fun tile(name: String): TextView {
        val words = name.replace(Regex("[^\\p{L}\\p{N}\\s]"), " ").trim().split(Regex("\\s+")).filter { it.isNotEmpty() }
        val ini = (if (words.size > 1) words[0].take(1) + words[1].take(1) else name.filter { it.isLetterOrDigit() }.take(2)).uppercase().ifEmpty { "TV" }
        var h = 0; for (ch in name) h = (h * 31 + ch.code) % 360
        return TextView(this).apply { text = ini; textSize = 14f; setTextColor(Color.WHITE); typeface = Typeface.DEFAULT_BOLD; gravity = Gravity.CENTER; background = bg(Color.HSVToColor(floatArrayOf(h.toFloat(), 0.42f, 0.46f)), 10) }
    }

    private fun channelRow(c: JSONObject): View {
        val name = c.optString("name")
        val wrap = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(dp(8), dp(7), dp(12), dp(7)) }
        row.addView(tv(c.optInt("n").toString(), 13f, ACC2, true).apply { gravity = Gravity.CENTER }, LinearLayout.LayoutParams(dp(38), -2))
        val logoBox = FrameLayout(this)
        val showTile = { logoBox.removeAllViews(); logoBox.addView(tile(name), FrameLayout.LayoutParams(-1, -1)) }
        val logo = c.optString("logo")
        if (logo.isEmpty()) showTile() else {
            val iv = ImageView(this).apply { scaleType = ImageView.ScaleType.FIT_CENTER; setPadding(dp(4), dp(4), dp(4), dp(4)); background = bg(Color.parseColor("#0B0F1F"), 10) }
            logoBox.addView(iv, FrameLayout.LayoutParams(-1, -1)); Img.load(iv, logo, 220) { showTile() }
        }
        row.addView(logoBox, LinearLayout.LayoutParams(dp(46), dp(46)).apply { setMargins(0, 0, dp(12), 0) })
        row.addView(tv(name, 15f), LinearLayout.LayoutParams(0, -2, 1f))
        wrap.addView(row); wrap.addView(View(this).apply { setBackgroundColor(LINE) }, LinearLayout.LayoutParams(-1, 1))
        return wrap
    }

    // ---------- ამინდი ----------
    private fun addWeatherHero(parent: LinearLayout, b: JSONObject) {
        val cols = when (b.optString("theme")) {
            "sun" -> intArrayOf(Color.parseColor("#1E88E5"), Color.parseColor("#64B5F6")); "night" -> intArrayOf(Color.parseColor("#0D1B3D"), Color.parseColor("#2A3F7A"))
            "rain" -> intArrayOf(Color.parseColor("#2C3E50"), Color.parseColor("#4B6584")); "storm" -> intArrayOf(Color.parseColor("#1F2023"), Color.parseColor("#4A4D55"))
            "snow" -> intArrayOf(Color.parseColor("#6D8197"), Color.parseColor("#B7C7D6")); "fog" -> intArrayOf(Color.parseColor("#59656F"), Color.parseColor("#9AA5AF"))
            else -> intArrayOf(Color.parseColor("#3E4A63"), Color.parseColor("#7384A3")) }
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; background = GradientDrawable(GradientDrawable.Orientation.TL_BR, cols).apply { cornerRadius = dp(20).toFloat() }; setPadding(dp(18), dp(18), dp(18), dp(18)) }
        box.addView(tv(b.optString("city"), 24f, Color.WHITE, true))
        if (b.optString("sub").isNotEmpty()) box.addView(tv(b.optString("sub"), 13f, Color.parseColor("#E8EEF7")))
        box.addView(tv(b.optString("date"), 13f, Color.parseColor("#E8EEF7")))
        val mid = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(0, dp(8), 0, dp(4)) }
        mid.addView(tv(b.optString("icon"), 54f)); mid.addView(tv(b.optString("temp"), 60f, Color.WHITE, true).apply { setPadding(dp(10), 0, 0, 0) })
        box.addView(mid)
        box.addView(tv(b.optString("desc"), 15f, Color.WHITE)); box.addView(tv(b.optString("range"), 14f, Color.parseColor("#E8EEF7")).apply { setPadding(0, dp(4), 0, 0) })
        parent.addView(box, lp(0, 12))
    }

    private fun addGrid(parent: LinearLayout, b: JSONObject) {
        val items = b.optJSONArray("items") ?: JSONArray(); val cols = b.optInt("cols", 2).coerceAtLeast(1); val compact = b.optBoolean("compact")
        var i = 0
        while (i < items.length()) {
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            for (k in 0 until cols) {
                val idx = i + k
                if (idx < items.length()) row.addView(gridCell(items.getJSONObject(idx), cols, compact), LinearLayout.LayoutParams(0, -2, 1f).apply { setMargins(dp(3), dp(3), dp(3), dp(3)) })
                else row.addView(View(this), LinearLayout.LayoutParams(0, 1, 1f))
            }
            parent.addView(row, LinearLayout.LayoutParams(-1, -2)); i += cols
        }
        parent.addView(View(this), LinearLayout.LayoutParams(-1, dp(8)))
    }

    private fun gridCell(it: JSONObject, cols: Int, compact: Boolean): View {
        val cell = LinearLayout(this).apply { background = framedBg(14) }
        if (cols >= 3) {
            cell.orientation = LinearLayout.VERTICAL; cell.gravity = Gravity.CENTER
            cell.addView(tv(it.optString("icon"), 24f).apply { gravity = Gravity.CENTER }); cell.addView(tv(it.optString("label"), 11.5f, MUTED).apply { gravity = Gravity.CENTER; maxLines = 1 })
            cell.setPadding(dp(4), dp(12), dp(4), dp(12))
        } else if (compact) {
            cell.orientation = LinearLayout.HORIZONTAL; cell.gravity = Gravity.CENTER_VERTICAL
            cell.addView(tv(it.optString("icon"), 20f)); cell.addView(tv(it.optString("label"), 13.5f).apply { setPadding(dp(8), 0, 0, 0); maxLines = 1 }, LinearLayout.LayoutParams(0, -2, 1f)); cell.addView(tv(it.optString("value"), 15f, ACC2, true))
            cell.setPadding(dp(12), dp(11), dp(12), dp(11))
        } else {
            cell.orientation = LinearLayout.VERTICAL
            val head = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
            head.addView(tv(it.optString("icon"), 15f)); head.addView(tv(it.optString("label"), 12.5f, MUTED).apply { setPadding(dp(6), 0, 0, 0) })
            cell.addView(head); cell.addView(tv(it.optString("value"), 18f, TXT, true).apply { setPadding(0, dp(4), 0, 0) })
            if (it.optString("sub").isNotEmpty()) cell.addView(tv(it.optString("sub"), 10.5f, MUTED))
            cell.setPadding(dp(12), dp(10), dp(12), dp(10))
        }
        val act = it.optJSONObject("action"); if (act != null) cell.setOnClickListener { perform(act) }
        return cell
    }

    // ---------------- ფორმა ----------------
    private fun addForm(parent: LinearLayout, b: JSONObject) {
        val getters = LinkedHashMap<String, () -> String>()
        val files = HashMap<String, Uri?>()
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; background = framedBg(16); setPadding(dp(16), dp(16), dp(16), dp(10)) }
        val fields = b.getJSONArray("fields")
        for (i in 0 until fields.length()) {
            val f = fields.getJSONObject(i); val name = f.getString("name"); val type = f.optString("type"); val label = f.optString("label")
            if (type == "hidden") { val v = f.optString("value"); getters[name] = { v }; continue }
            if (type == "actionbtn") {
                val uses = f.optJSONArray("uses") ?: JSONArray()
                val btn = button(f.optString("btn"), "secondary") { }
                btn.setOnClickListener {
                    val m = HashMap<String, String>(); for (u in 0 until uses.length()) { val k = uses.getString(u); m[k] = getters[k]?.invoke() ?: "" }
                    btn.isEnabled = false; doAct(f.getString("act"), m, emptyList()) { btn.isEnabled = true }
                }
                box.addView(btn); continue
            }
            if (label.isNotEmpty() && type != "checkbox") box.addView(tv(label, 13f, MUTED).apply { setPadding(0, dp(4), 0, dp(4)) })
            when (type) {
                "select" -> {
                    val opts = f.optJSONArray("options") ?: JSONArray(); val vals = ArrayList<String>(); val labs = ArrayList<String>()
                    for (k in 0 until opts.length()) { val o = opts.getJSONArray(k); vals.add(o.optString(0)); labs.add(o.optString(1)) }
                    val sp = Spinner(this); sp.adapter = object : ArrayAdapter<String>(this, android.R.layout.simple_spinner_dropdown_item, labs) {
                        override fun getView(p: Int, c: View?, g: ViewGroup): View = (super.getView(p, c, g) as TextView).apply { setTextColor(TXT) }
                    }
                    val idx = vals.indexOf(f.optString("value")); if (idx >= 0) sp.setSelection(idx)
                    sp.background = bg(BG2, 10, LINE)
                    box.addView(sp, lp(0, 10)); getters[name] = { if (vals.isEmpty()) "" else vals[sp.selectedItemPosition] }
                }
                "checkbox" -> { val cb = CheckBox(this).apply { text = label; setTextColor(TXT); isChecked = f.optString("value") == "1" }; box.addView(cb, lp(0, 8)); getters[name] = { if (cb.isChecked) "1" else "0" } }
                "file" -> {
                    val info = tv(S.t("no_file"), 13f, MUTED)
                    box.addView(button(S.t("pick_file"), "secondary") {
                        pickTarget = { uri -> files[name] = uri; info.text = S.t("file_ok"); info.setTextColor(GREEN) }
                        val i = Intent(Intent.ACTION_GET_CONTENT).setType("*/*").addCategory(Intent.CATEGORY_OPENABLE).putExtra(Intent.EXTRA_MIME_TYPES, arrayOf("image/*", "application/pdf"))
                        startActivityForResult(Intent.createChooser(i, S.t("pick_receipt")), REQ_PICK)
                    }); box.addView(info, lp(0, 10)); getters[name] = { if (files[name] != null) "1" else "" }
                }
                else -> {
                    val et = EditText(this).apply {
                        hint = f.optString("placeholder"); setHintTextColor(Color.parseColor("#59638C")); setTextColor(TXT); textSize = 15f; background = bg(BG2, 10, LINE); setPadding(dp(12), dp(11), dp(12), dp(11))
                        setText(f.optString("value"))
                        inputType = when (type) { "email" -> InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_EMAIL_ADDRESS; "password" -> InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
                            "phone" -> InputType.TYPE_CLASS_NUMBER; "number" -> InputType.TYPE_CLASS_NUMBER; "textarea" -> InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE or InputType.TYPE_TEXT_FLAG_CAP_SENTENCES; else -> InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_CAP_SENTENCES }
                        if (type == "textarea") { minLines = 3; gravity = Gravity.TOP }
                    }
                    box.addView(et, lp(0, 6)); getters[name] = { et.text.toString().trim() }
                    fieldViews.add { et.text.isNotEmpty() && type != "hidden" }
                    if (f.optString("hint").isNotEmpty()) box.addView(tv(f.optString("hint"), 11.5f, MUTED), lp(0, 8))
                }
            }
        }
        val sub = b.getJSONObject("submit")
        val btn = button(sub.optString("label"), "primary") { }
        btn.setOnClickListener {
            val m = HashMap<String, String>()
            for ((k, g) in getters) m[k] = g()
            sub.optJSONObject("f")?.let { o -> o.keys().forEach { k -> m[k] = o.optString(k) } }
            // ფაილის ველების მნიშვნელობები (ბაიტები კი multipart-ით მიდის)
            val up = ArrayList<UploadFile>(); for ((k, u) in files) if (u != null) { up.add(UploadFile(k, u)); m.remove(k) }
            (currentFocus)?.let { (getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager).hideSoftInputFromWindow(it.windowToken, 0) }
            btn.isEnabled = false; doAct(sub.getString("act"), m, up) { btn.isEnabled = true }
        }
        box.addView(btn, lp(6, 6))
        parent.addView(box, lp(0, 14))
    }

    // ---------------- ლოკაცია / ფაილი ----------------
    private fun hasLoc() = ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED || ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED
    @Suppress("MissingPermission")
    private fun lastLocation(): Pair<Double, Double>? {
        if (!hasLoc()) return null
        return try {
            val lm = getSystemService(Context.LOCATION_SERVICE) as LocationManager
            var best: android.location.Location? = null
            for (p in lm.getProviders(true)) { val l = lm.getLastKnownLocation(p) ?: continue; if (best == null || l.time > best.time) best = l }
            best?.let { Pair(it.latitude, it.longitude) }
        } catch (e: Exception) { null }
    }
    private fun locateAndReload() {
        if (!hasLoc()) { pendingLocate = true; ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION), REQ_LOC); return }
        toast(S.t("locating"))
        val l = lastLocation()
        if (l == null) { toast(S.t("no_loc")); return }
        val st = stacks[tab] ?: return
        if (st.isNotEmpty() && st.last().id == "weather") st.removeAt(st.size - 1)
        st.add(Frame("weather", mapOf("lat" to l.first.toString(), "lon" to l.second.toString()))); reload()
    }
    override fun onRequestPermissionsResult(code: Int, perms: Array<out String>, res: IntArray) {
        super.onRequestPermissionsResult(code, perms, res)
        if (code == REQ_LOC && hasLoc()) { if (pendingLocate) { pendingLocate = false; locateAndReload() } else if (cur()?.id == "weather") reload() }
    }
    @Deprecated("Deprecated in Java")
    override fun onActivityResult(req: Int, res: Int, data: Intent?) {
        super.onActivityResult(req, res, data)
        if (req == REQ_PICK && res == Activity.RESULT_OK) data?.data?.let { pickTarget?.invoke(it) }
    }
}
