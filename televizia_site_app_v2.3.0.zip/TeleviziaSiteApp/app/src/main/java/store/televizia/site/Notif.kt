package store.televizia.site

import android.Manifest
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.work.*
import java.util.concurrent.TimeUnit

/** საიტის შეტყობინებები ტელეფონის სისტემურ შეტყობინებებად (აპლიკაცია დახურულზეც — ფონური შემოწმება ~15 წუთში ერთხელ) */
object Notif {
    private const val CH = "site_notif"

    fun schedule(ctx: Context) {
        val req = PeriodicWorkRequestBuilder<NotifWorker>(15, TimeUnit.MINUTES)
            .setConstraints(Constraints.Builder().setRequiredNetworkType(NetworkType.CONNECTED).build()).build()
        WorkManager.getInstance(ctx).enqueueUniquePeriodicWork("site_notif", ExistingPeriodicWorkPolicy.UPDATE, req)
    }
    fun reset(ctx: Context) { ctx.getSharedPreferences("notif", Context.MODE_PRIVATE).edit().putInt("last", -1).apply() }

    /** ახალი შეტყობინებების მიღება და ჩვენება; პირველი გამოძახება მხოლოდ საწყის წერტილს იმახსოვრებს */
    fun poll(ctx: Context) {
        if (Api.token.isEmpty()) return
        val sp = ctx.getSharedPreferences("notif", Context.MODE_PRIVATE)
        val last = sp.getInt("last", -1)
        val r = Api.act("notif_poll", mapOf("after" to last.toString()), emptyList())
        if (!r.optBoolean("ok")) return
        val items = r.optJSONArray("items")
        if (last >= 0 && items != null) for (i in 0 until items.length()) { val n = items.getJSONObject(i); show(ctx, n.optInt("id"), n.optString("title"), n.optString("body")) }
        sp.edit().putInt("last", r.optInt("max", last)).apply()
    }

    private fun show(ctx: Context, id: Int, title: String, body: String) {
        if (Build.VERSION.SDK_INT >= 33 && ctx.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) return
        val nm = ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= 26) nm.createNotificationChannel(NotificationChannel(CH, ctx.getString(R.string.app_name), NotificationManager.IMPORTANCE_HIGH))
        val pi = PendingIntent.getActivity(ctx, id, Intent(ctx, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP), PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        val n = NotificationCompat.Builder(ctx, CH).setSmallIcon(ctx.applicationInfo.icon).setContentTitle(title).setContentText(body)
            .setStyle(NotificationCompat.BigTextStyle().bigText(body)).setAutoCancel(true).setContentIntent(pi).setPriority(NotificationCompat.PRIORITY_HIGH).setDefaults(NotificationCompat.DEFAULT_ALL).build()
        nm.notify(10000 + id, n)
    }
}

class NotifWorker(c: Context, p: WorkerParameters) : Worker(c, p) {
    override fun doWork(): Result {
        try { Api.init(applicationContext); Notif.poll(applicationContext) } catch (e: Exception) { }
        return Result.success()
    }
}
