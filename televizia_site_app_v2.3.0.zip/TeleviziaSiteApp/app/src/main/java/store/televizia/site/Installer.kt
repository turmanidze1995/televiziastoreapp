package store.televizia.site

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.provider.Settings
import android.view.Gravity
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import androidx.core.content.FileProvider
import java.io.File
import java.net.HttpURLConnection
import java.net.URL

/** აპლიკაციის შიგნით გადმოწერა და დაყენება (APK) — საიტის აპლიკაციის განახლებისთვის და TELEVIZIA.STORE-ის დასაყენებლად */
object Installer {
    var pending: File? = null

    fun download(act: Activity, url: String, title: String) {
        val bar = ProgressBar(act, null, android.R.attr.progressBarStyleHorizontal).apply { max = 100; isIndeterminate = true }
        val txt = TextView(act).apply { text = "0%"; gravity = Gravity.CENTER; setPadding(0, 12, 0, 0) }
        val box = LinearLayout(act).apply { orientation = LinearLayout.VERTICAL; setPadding(48, 32, 48, 16); addView(bar); addView(txt) }
        var cancelled = false
        val dlg = AlertDialog.Builder(act).setTitle(title).setView(box).setCancelable(false).setNegativeButton(S.t("cancel")) { _, _ -> cancelled = true }.show()
        Thread {
            var ok = false; var file: File? = null
            try {
                var u = url; var conn: HttpURLConnection? = null
                for (i in 0 until 6) {
                    conn = URL(u).openConnection() as HttpURLConnection
                    conn.instanceFollowRedirects = false; conn.connectTimeout = 15000; conn.readTimeout = 30000
                    conn.setRequestProperty("User-Agent", "TeleviziaSiteApp")
                    val c = conn.responseCode
                    if (c in 300..399) { u = URL(URL(u), conn.getHeaderField("Location")).toString(); conn.disconnect(); continue }
                    break
                }
                val c = conn!!
                if (c.responseCode !in 200..299) throw Exception("http " + c.responseCode)
                val total = c.contentLengthLong
                val dir = File(act.cacheDir, "apk"); dir.mkdirs(); dir.listFiles()?.forEach { it.delete() }
                val f2 = File(dir, "update.apk"); file = f2
                c.inputStream.use { ins -> f2.outputStream().use { out ->
                    val buf = ByteArray(64 * 1024); var done = 0L; var last = -1
                    while (true) {
                        if (cancelled) throw Exception("cancel")
                        val n = ins.read(buf); if (n < 0) break
                        out.write(buf, 0, n); done += n
                        if (total > 0) { val p = (done * 100 / total).toInt(); if (p != last) { last = p; act.runOnUiThread { bar.isIndeterminate = false; bar.progress = p; txt.text = "$p%" } } }
                    }
                } }
                ok = true
            } catch (e: Exception) { }
            val res = file
            act.runOnUiThread {
                try { dlg.dismiss() } catch (e: Exception) { }
                if (ok && res != null) install(act, res) else if (!cancelled) Toast.makeText(act, S.t("noconn"), Toast.LENGTH_LONG).show()
            }
        }.start()
    }

    fun install(act: Activity, f: File) {
        if (Build.VERSION.SDK_INT >= 26 && !act.packageManager.canRequestPackageInstalls()) {
            pending = f
            Toast.makeText(act, S.t("allow_install"), Toast.LENGTH_LONG).show()
            try { act.startActivity(Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES, Uri.parse("package:" + act.packageName))) } catch (e: Exception) { }
            return
        }
        pending = null
        try {
            val uri = FileProvider.getUriForFile(act, act.packageName + ".fp", f)
            act.startActivity(Intent(Intent.ACTION_VIEW).setDataAndType(uri, "application/vnd.android.package-archive").addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK))
        } catch (e: Exception) { Toast.makeText(act, S.t("link_fail"), Toast.LENGTH_LONG).show() }
    }

    /** ნებართვის მიცემის შემდეგ აპლიკაციაში დაბრუნებისას დაყენება გრძელდება */
    fun resume(act: Activity) {
        val f = pending ?: return
        if (Build.VERSION.SDK_INT < 26 || act.packageManager.canRequestPackageInstalls()) install(act, f)
    }
}
