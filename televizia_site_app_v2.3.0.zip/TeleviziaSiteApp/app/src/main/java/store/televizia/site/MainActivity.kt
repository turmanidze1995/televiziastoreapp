package store.televizia.site

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.app.Dialog
import android.view.WindowManager
import androidx.viewpager.widget.ViewPager
import android.location.LocationManager
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.InputMethodManager
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout
import androidx.core.widget.TextViewCompat
import org.json.JSONArray
import org.json.JSONObject

/** ნატიური (WebView-ის გარეშე) საიტის აპლიკაცია: სერვერი აბრუნებს ეკრანებს (ბლოკების სიას), აპლიკაცია ხატავს ნატიურ ელემენტებს */
class MainActivity : AppCompatActivity() {

    private val BG = Color.parseColor("#0B0E14"); private val BG2 = Color.parseColor("#131722"); private val CARD = Color.parseColor("#1A1F2E"); private val LINE = Color.parseColor("#262C3D")
    private val TXT = Color.parseColor("#F2F3F7"); private val MUTED = Color.parseColor("#9AA0B4"); private val ACC = Color.parseColor("#6C5CE7"); private val ACC2 = Color.parseColor("#00D9C0")
    private val RED = Color.parseColor("#E5484D"); private val GREEN = Color.parseColor("#2ECC71"); private val AMBER = Color.parseColor("#F5A524")

    private val main = Handler(Looper.getMainLooper())
    private class Frame(val id: String, val params: Map<String, String>)
    private val stacks = HashMap<String, ArrayList<Frame>>()
    private var tabs = JSONArray()
    private var tab = "home"
    private var site = "TELEVIZIA.STORE"

    private lateinit var title: TextView
    private lateinit var nameTv: TextView
    private lateinit var rootLayout: LinearLayout
    private var navDir = 0
    private var socialCode: String? = null
    private var socialTries = 0
    private var updateChecked = false
    private var songWeb: android.webkit.WebView? = null
    private lateinit var mini: LinearLayout
    private lateinit var row2: LinearLayout
    private lateinit var guestBox: LinearLayout
    private lateinit var back: TextView
    private lateinit var tabBar: LinearLayout
    private lateinit var content: LinearLayout
    private lateinit var swipe: SwipeRefreshLayout
    private lateinit var banner: TextView
    private lateinit var topRight: LinearLayout
    private var loggedIn = false
    private var userName = ""
    private var pendingLocate = false
    private lateinit var progress: ProgressBar
    private var gen = 0                       // მოძველებული პასუხების გამოსარიცხად
    private var refreshRunnable: Runnable? = null
    private val fieldViews = ArrayList<() -> Boolean>()   // true = ველი შევსებულია (ავტო-განახლებას აჩერებს)

    // ფაილის არჩევა
    private var pickTarget: ((Uri) -> Unit)? = null
    private val REQ_PICK = 8801; private val REQ_LOC = 8802
    private var askedLoc = false

    private fun dp(v: Int) = (v * resources.displayMetrics.density + 0.5f).toInt()
    private fun bg(color: Int, r: Int = 12, stroke: Int = 0): GradientDrawable = GradientDrawable().apply {
        setColor(color); cornerRadius = dp(r).toFloat(); if (stroke != 0) setStroke(dp(1), stroke)
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        Api.init(this)
        buildShell()
        loadBoot()
    }

    // ---------------- გარსი ----------------
    private fun buildShell() {
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(BG) }
        rootLayout = root
        val top = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(BG2); setPadding(dp(6), dp(4), dp(10), dp(4)) }
        val row1 = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        back = TextView(this).apply { text = "←"; textSize = 20f; setTextColor(TXT); gravity = Gravity.CENTER; typeface = Typeface.DEFAULT_BOLD; background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(CARD); setStroke(dp(1), ACC2) }; visibility = View.GONE; setOnClickListener { goBack() } }
        nameTv = TextView(this).apply {
            text = site; gravity = Gravity.CENTER_VERTICAL; setTextColor(Color.WHITE); typeface = Typeface.DEFAULT_BOLD; maxLines = 1; setPadding(dp(8), 0, dp(6), 0); includeFontPadding = false
            TextViewCompat.setAutoSizeTextTypeUniformWithConfiguration(this, 12, 22, 1, android.util.TypedValue.COMPLEX_UNIT_SP)
            addOnLayoutChangeListener { v, _, _, _, _, _, _, _, _ -> val t = v as TextView; val w = t.paint.measureText(t.text.toString())
                t.paint.shader = android.graphics.LinearGradient(0f, 0f, w, 0f, intArrayOf(ACC, ACC2), null, android.graphics.Shader.TileMode.CLAMP); t.invalidate() }
        }
        topRight = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        row1.addView(back, LinearLayout.LayoutParams(dp(40), dp(40)).apply { setMargins(dp(4), 0, dp(2), 0) }); row1.addView(nameTv, LinearLayout.LayoutParams(0, dp(44), 1f)); row1.addView(topRight, LinearLayout.LayoutParams(-2, dp(44)))
        title = TextView(this).apply {
            gravity = Gravity.CENTER_VERTICAL; setTextColor(TXT); typeface = Typeface.DEFAULT_BOLD; maxLines = 1; setPadding(dp(8), 0, dp(6), 0)
            TextViewCompat.setAutoSizeTextTypeUniformWithConfiguration(this, 11, 18, 1, android.util.TypedValue.COMPLEX_UNIT_SP)
        }
        guestBox = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        row2 = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        row2.addView(title, LinearLayout.LayoutParams(0, dp(34), 1f)); row2.addView(guestBox, LinearLayout.LayoutParams(-2, dp(34)))
        top.addView(row1, LinearLayout.LayoutParams(-1, -2)); top.addView(row2, LinearLayout.LayoutParams(-1, -2))
        root.addView(top, LinearLayout.LayoutParams(-1, -2))
        root.addView(View(this).apply { setBackgroundColor(LINE) }, LinearLayout.LayoutParams(-1, 1))

        val frame = FrameLayout(this)
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        banner = TextView(this).apply { textSize = 14f; setTextColor(Color.WHITE); setPadding(dp(14), dp(10), dp(14), dp(10)); visibility = View.GONE; setOnClickListener { visibility = View.GONE } }
        col.addView(banner, LinearLayout.LayoutParams(-1, -2))
        swipe = SwipeRefreshLayout(this)
        swipe.setColorSchemeColors(ACC, ACC2)
        val sv = ScrollView(this).apply { isFillViewport = true; clipToPadding = false }
        content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(14), dp(12), dp(14), dp(24)) }
        sv.addView(content, FrameLayout.LayoutParams(-1, -2))
        swipe.addView(sv)
        swipe.setOnRefreshListener { reload() }
        col.addView(swipe, LinearLayout.LayoutParams(-1, 0, 1f))
        frame.addView(col, FrameLayout.LayoutParams(-1, -1))
        progress = ProgressBar(this).apply { visibility = View.GONE }
        frame.addView(progress, FrameLayout.LayoutParams(dp(44), dp(44), Gravity.CENTER))
        root.addView(frame, LinearLayout.LayoutParams(-1, 0, 1f))
        mini = buildMiniPlayer(); root.addView(mini, LinearLayout.LayoutParams(-1, -2))

        root.addView(View(this).apply { setBackgroundColor(LINE) }, LinearLayout.LayoutParams(-1, 1))
        tabBar = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; setBackgroundColor(BG2); setPadding(dp(4), dp(4), dp(4), dp(4)) }
        root.addView(tabBar, LinearLayout.LayoutParams(-1, dp(62)))
        setContentView(root)
        buildTopRight()
    }

    /** ზედა პანელის მარჯვენა მხარე: ენა + (სტუმარი: შესვლა | მომხმარებელი: შეტყობინება + ავატარი) */
    private fun buildTopRight() {
        topRight.removeAllViews(); guestBox.removeAllViews()
        val lang = TextView(this).apply {
            text = "🌐 " + S.lang.uppercase(); textSize = 12f; setTextColor(TXT); typeface = Typeface.DEFAULT_BOLD; gravity = Gravity.CENTER
            background = bg(CARD, 16, LINE); setPadding(dp(10), dp(6), dp(10), dp(6)); setOnClickListener { showLangDialog() }
        }
        topRight.addView(lang, LinearLayout.LayoutParams(-2, -2).apply { setMargins(0, 0, dp(4), 0) })
        if (!loggedIn) {
            val pill = TextView(this).apply {
                text = S.t("login"); textSize = 12.5f; setTextColor(Color.WHITE); typeface = Typeface.DEFAULT_BOLD; gravity = Gravity.CENTER; setPadding(dp(14), dp(6), dp(14), dp(6)); maxLines = 1
                background = GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, intArrayOf(ACC, Color.parseColor("#4B3FC7"))).apply { cornerRadius = dp(16).toFloat() }
                setOnClickListener { perform(JSONObject().put("a", "root").put("id", "login")) }
            }
            guestBox.addView(pill, LinearLayout.LayoutParams(-2, -2).apply { setMargins(0, 0, dp(6), 0) })
            val reg = TextView(this).apply {
                text = S.t("register"); textSize = 12.5f; setTextColor(ACC2); typeface = Typeface.DEFAULT_BOLD; gravity = Gravity.CENTER; setPadding(dp(12), dp(5), dp(12), dp(5)); maxLines = 1
                background = bg(Color.TRANSPARENT, 16, ACC2); setOnClickListener { perform(JSONObject().put("a", "root").put("id", "register")) }
            }
            guestBox.addView(reg)
        } else {
            val bell = TextView(this).apply { text = "🔔"; textSize = 18f; gravity = Gravity.CENTER; setPadding(dp(8), 0, dp(8), 0); setOnClickListener { perform(JSONObject().put("a", "screen").put("id", "notifications")) } }
            topRight.addView(bell, LinearLayout.LayoutParams(-2, -2))
            val av = TextView(this).apply {
                text = userName.trim().take(1).uppercase().ifEmpty { "👤" }; textSize = 15f; setTextColor(Color.WHITE); typeface = Typeface.DEFAULT_BOLD; gravity = Gravity.CENTER
                background = GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(ACC, ACC2)).apply { shape = GradientDrawable.OVAL }
                setOnClickListener { selectTab("account") }
            }
            topRight.addView(av, LinearLayout.LayoutParams(dp(34), dp(34)))
        }
        nameTv.text = site; updateRow2()
    }
    private fun updateRow2() { row2.visibility = if (!loggedIn || title.text.isNotEmpty()) View.VISIBLE else View.GONE }

    private fun showLangDialog() {
        val names = arrayOf("ქართული", "English", "Русский"); val codes = arrayOf("ka", "en", "ru")
        AlertDialog.Builder(this).setTitle("🌐 " + S.t("lang_title")).setSingleChoiceItems(names, codes.indexOf(S.lang)) { d, i ->
            d.dismiss()
            if (codes[i] != S.lang) {
                Api.lang = codes[i]
                for (k in stacks.keys) stacks[k] = arrayListOf()
                content.removeAllViews(); buildTopRight(); loadBoot()
            }
        }.show()
    }

    private fun buildTabs() {
        tabBar.removeAllViews()
        for (i in 0 until tabs.length()) {
            val t = tabs.getJSONObject(i); val id = t.getString("id"); val on = id == tab
            val v = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER; setOnClickListener { selectTab(id) }
                if (on) background = bg(Color.argb(46, 108, 92, 231), 14, Color.argb(120, 108, 92, 231)) }
            v.addView(TextView(this).apply { text = t.optString("icon"); textSize = if (on) 22f else 20f; gravity = Gravity.CENTER })
            v.addView(TextView(this).apply { text = t.optString("label"); textSize = 9.5f; gravity = Gravity.CENTER; maxLines = 2; setTextColor(if (on) ACC2 else MUTED); if (on) typeface = Typeface.DEFAULT_BOLD })
            tabBar.addView(v, LinearLayout.LayoutParams(0, -1, 1f).apply { setMargins(dp(2), 0, dp(2), 0) })
        }
    }

    private fun loadBoot() {
        progress.visibility = View.VISIBLE
        Thread {
            val r = Api.screen("boot", emptyMap())
            main.post {
                progress.visibility = View.GONE
                if (r.optBoolean("ok") && r.has("tabs")) {
                    tabs = r.getJSONArray("tabs"); site = r.optString("site", site).ifEmpty { site }; loggedIn = r.optBoolean("logged_in"); userName = r.optString("user"); buildTopRight()
                    if (stacks.isEmpty()) for (i in 0 until tabs.length()) stacks[tabs.getJSONObject(i).getString("id")] = arrayListOf()
                    buildTabs(); selectTab(tab); startNotifWatch(); checkSelfUpdate()
                } else showError(r.optString("error", S.t("error"))) { loadBoot() }
            }
        }.start()
    }

    private fun selectTab(id: String) {
        tab = id; buildTabs()
        val st = stacks.getOrPut(id) { arrayListOf() }
        if (st.isEmpty()) st.add(Frame(id, emptyMap()))
        reload()
    }

    private fun cur(): Frame? = stacks[tab]?.lastOrNull()
    private fun goBack() { val st = stacks[tab] ?: return; if (st.size > 1) { st.removeAt(st.size - 1); navDir = -1; reload() } }
    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        val st = stacks[tab]
        if (st != null && st.size > 1) goBack()
        else if (tab != "home") selectTab("home")
        else super.onBackPressed()
    }

    // ---------------- ეკრანის ჩატვირთვა ----------------
    private fun reload() {
        val f = cur() ?: return
        val my = ++gen
        refreshRunnable?.let { main.removeCallbacks(it) }
        banner.visibility = View.GONE
        var p = f.params
        if (f.id == "weather" && !p.containsKey("lat") && !p.containsKey("c")) { val l = lastLocation(); if (l != null) p = p + mapOf("lat" to l.first.toString(), "lon" to l.second.toString()) }
        if (navDir != 0) content.animate().alpha(0.25f).setDuration(120).start()
        if (!swipe.isRefreshing && (content.childCount == 0 || navDir != 0)) progress.visibility = View.VISIBLE
        Thread {
            val r = Api.screen(f.id, p)
            main.post {
                if (my != gen) return@post
                progress.visibility = View.GONE; swipe.isRefreshing = false
                render(f, r)
            }
        }.start()
    }

    private fun showError(msg: String, retry: (() -> Unit)?) {
        content.removeAllViews()
        content.addView(TextView(this).apply { text = "⚠️ $msg"; setTextColor(TXT); textSize = 16f; gravity = Gravity.CENTER; setPadding(0, dp(40), 0, dp(16)) })
        if (retry != null) content.addView(button(S.t("retry"), "primary") { retry() })
    }

    private fun render(f: Frame, r: JSONObject) {
        content.removeAllViews(); fieldViews.clear()
        val st = stacks[tab]!!
        back.visibility = if (st.size > 1) View.VISIBLE else View.GONE
        if (!r.optBoolean("ok", true) || !r.has("blocks")) { content.animate().cancel(); content.alpha = 1f; content.translationX = 0f; navDir = 0; title.text = ""; updateRow2(); showError(r.optString("error", S.t("screen_fail"))) { reload() }; return }
        title.text = if (st.size > 1 || f.id != tab) r.optString("title", "") else ""; updateRow2()
        val blocks = r.getJSONArray("blocks")
        for (i in 0 until blocks.length()) addBlock(content, blocks.getJSONObject(i))
        content.animate().cancel()
        if (navDir != 0) { content.translationX = (navDir * dp(56)).toFloat(); content.alpha = 0f; content.animate().translationX(0f).alpha(1f).setDuration(230).start() } else { content.translationX = 0f; content.alpha = 1f }
        navDir = 0
        val rf = r.optInt("refresh", 0)
        if (rf > 0) {
            val run = Runnable { if (fieldViews.none { it() }) reload() else refreshRunnable?.let { main.postDelayed(it, rf * 1000L) } }
            refreshRunnable = run; main.postDelayed(run, rf * 1000L)
        }
        if (r.optBoolean("wants_location") && !askedLoc && !hasLoc()) { askedLoc = true; ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION), REQ_LOC) }
    }

    // ---------------- მოქმედებები ----------------
    private fun perform(a: JSONObject?) {
        if (a == null) return
        when (a.optString("a")) {
            "screen" -> { stacks[tab]!!.add(Frame(a.getString("id"), params(a.optJSONObject("p")))); navDir = 1; reload() }
            "replace" -> { val st = stacks[tab]!!; if (st.isNotEmpty()) st.removeAt(st.size - 1); st.add(Frame(a.getString("id"), params(a.optJSONObject("p")))); reload() }
            "root" -> {
                val id = a.getString("id"); val p = params(a.optJSONObject("p"))
                val target = if (isTab(id)) id else if (id == "login" || id == "register") "account" else tab
                stacks[target] = arrayListOf(Frame(if (isTab(id)) id else target, emptyMap()))
                if (!isTab(id)) stacks[target]!!.add(Frame(id, p))
                tab = target; buildTabs(); reload()
            }
            "back" -> goBack()
            "lang" -> showLangDialog()
            "locate" -> locateAndReload()
            "tvapp" -> openTvApp()
            "social" -> startSocial(a.optString("provider"))
            "act" -> {
                val f = HashMap<String, String>(); a.optJSONObject("f")?.let { o -> o.keys().forEach { k -> f[k] = o.optString(k) } }
                val go = { doAct(a.getString("id"), f, emptyList(), null) }
                val c = a.optString("confirm")
                if (c.isNotEmpty()) AlertDialog.Builder(this).setMessage(c).setPositiveButton(S.t("yes")) { _, _ -> go() }.setNegativeButton(S.t("cancel"), null).show() else go()
            }
            "url" -> try { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(a.getString("url")))) } catch (e: Exception) { toast(S.t("link_fail")) }
            "copy" -> { (getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager).setPrimaryClip(ClipData.newPlainText("t", a.optString("text"))); toast(a.optString("toast", S.t("copied"))) }
            "share" -> startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, a.optString("text")), S.t("share")))
            "app" -> {
                val i = packageManager.getLaunchIntentForPackage(a.optString("pkg"))
                try { if (i != null) startActivity(i) else if (a.optString("url").isNotEmpty()) startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(a.optString("url")))) } catch (e: Exception) { }
            }
        }
    }
    private fun isTab(id: String): Boolean { for (i in 0 until tabs.length()) if (tabs.getJSONObject(i).getString("id") == id) return true; return false }
    private fun params(o: JSONObject?): Map<String, String> { val m = HashMap<String, String>(); o?.keys()?.forEach { k -> m[k] = o.optString(k) }; return m }

    private fun doAct(id: String, f: Map<String, String>, files: List<UploadFile>, done: (() -> Unit)?, silent: Boolean = false) {
        if (!silent) progress.visibility = View.VISIBLE
        Thread {
            val r = Api.act(id, f, files)
            main.post { if (!silent) progress.visibility = View.GONE; done?.invoke(); handleAct(id, r, silent) }
        }.start()
    }

    private fun handleAct(id: String, r: JSONObject, silent: Boolean = false) {
        if (r.optString("token").isNotEmpty()) { Api.token = r.getString("token"); Notif.reset(this) }
        if (r.optBoolean("logout")) { Api.token = ""; Notif.reset(this) }
        if (r.optBoolean("ok")) {
            if (r.optString("toast").isNotEmpty()) say(r.getString("toast"), true)
            if (r.optString("token").isNotEmpty() || r.optBoolean("logout")) {
                val nav = r.optJSONObject("nav")
                for (k in stacks.keys) stacks[k] = arrayListOf()
                Thread { val b = Api.screen("boot", emptyMap()); main.post { if (b.has("tabs")) { tabs = b.getJSONArray("tabs"); loggedIn = b.optBoolean("logged_in"); userName = b.optString("user"); buildTopRight() }; buildTabs(); if (nav != null) perform(nav) else selectTab("home"); startNotifWatch() } }.start()
            } else if (r.optJSONObject("nav") != null) perform(r.optJSONObject("nav"))
        } else if (!silent) say(r.optString("error", S.t("error")), false)
    }

    private fun say(msg: String, ok: Boolean) {
        banner.text = msg; banner.setBackgroundColor(if (ok) Color.parseColor("#1E7F4F") else Color.parseColor("#9B2C30")); banner.visibility = View.VISIBLE
        main.postDelayed({ if (banner.text == msg) banner.visibility = View.GONE }, if (ok) 4000 else 7000)
    }
    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()

    // ---------------- ბლოკები ----------------
    private fun lp(top: Int = 0, bottom: Int = 10) = LinearLayout.LayoutParams(-1, -2).apply { setMargins(0, dp(top), 0, dp(bottom)) }
    private fun tv(text: String, size: Float, color: Int = TXT, bold: Boolean = false) = TextView(this).apply {
        this.text = text; textSize = size; setTextColor(color); if (bold) typeface = Typeface.DEFAULT_BOLD; setLineSpacing(0f, 1.15f)
    }
    private fun button(label: String, style: String, onClick: () -> Unit) = Button(this).apply {
        text = label; isAllCaps = false; textSize = 15f; setTextColor(TXT); typeface = Typeface.DEFAULT_BOLD
        stateListAnimator = null
        background = when (style) {
            "secondary" -> framedBg(12)
            "danger" -> bg(RED, 12)
            else -> GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, intArrayOf(ACC, Color.parseColor("#3D8BE8"))).apply { cornerRadius = dp(12).toFloat() }
        }
        setPadding(dp(14), dp(12), dp(14), dp(12)); layoutParams = lp(0, 10); setOnClickListener { onClick() }
    }

    /** საიტის „გრადიენტული ჩარჩო“: იისფერი→ცისფერი კონტური + მუქი ბარათი. padding დააყენეთ ფონის შემდეგ! */
    private fun framedBg(r: Int = 16): android.graphics.drawable.Drawable {
        val outer = GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(Color.argb(190, 108, 92, 231), Color.argb(190, 0, 217, 192))).apply { cornerRadius = dp(r).toFloat() }
        val inner = GradientDrawable().apply { setColor(CARD); cornerRadius = dp(r - 2).toFloat() }
        return android.graphics.drawable.LayerDrawable(arrayOf(outer, inner)).apply { setLayerInset(1, dp(2), dp(2), dp(2), dp(2)) }
    }
    private fun roundClip(v: View, r: Int) {
        v.outlineProvider = object : android.view.ViewOutlineProvider() {
            override fun getOutline(view: View, o: android.graphics.Outline) { o.setRoundRect(0, 0, view.width, view.height, dp(r).toFloat()) }
        }
        v.clipToOutline = true
    }

    private fun addBlock(parent: LinearLayout, b: JSONObject) {
        when (b.optString("t")) {
            "hero" -> parent.addView(LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL; background = GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(ACC, Color.parseColor("#2A9FB8"))).apply { cornerRadius = dp(18).toFloat() }
                setPadding(dp(18), dp(20), dp(18), dp(20)); addView(tv(b.optString("title"), 22f, Color.WHITE, true))
                if (b.optString("sub").isNotEmpty()) addView(tv(b.optString("sub"), 14f, Color.parseColor("#E6F6FF")).apply { setPadding(0, dp(6), 0, 0) })
            }, lp(0, 14))
            "text" -> {
                val s = b.optString("style")
                parent.addView(when (s) {
                    "h1" -> tv(b.optString("text"), 21f, TXT, true); "h2" -> pillTitle(b.optString("text"), 15f)
                    "muted" -> tv(b.optString("text"), 13f, MUTED); "small" -> tv(b.optString("text"), 12f, MUTED)
                    "center" -> tv(b.optString("text"), 15f).apply { gravity = Gravity.CENTER }
                    else -> tv(b.optString("text"), 15f, Color.parseColor("#DDE1EE")) }, lp(0, 10))
            }
            "button" -> { val act = b.optJSONObject("action"); parent.addView(button(b.optString("label"), b.optString("style")) { perform(act) }) }
            "notice" -> {
                val c = when (b.optString("kind")) { "ok" -> GREEN; "warn" -> AMBER; "error" -> RED; else -> ACC2 }
                parent.addView(tv(b.optString("text"), 14f).apply { background = bg(Color.argb(40, Color.red(c), Color.green(c), Color.blue(c)), 12, c); setPadding(dp(14), dp(12), dp(14), dp(12)) }, lp(0, 12))
            }
            "card" -> addCard(parent, b)
            "kv" -> {
                val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; background = framedBg(16); setPadding(dp(16), dp(12), dp(16), dp(12)) }
                if (b.optString("title").isNotEmpty()) box.addView(tv(b.optString("title"), 15f, TXT, true).apply { setPadding(0, 0, 0, dp(6)) })
                val rows = b.optJSONArray("rows") ?: JSONArray()
                for (i in 0 until rows.length()) { val r = rows.getJSONArray(i)
                    box.addView(LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; setPadding(0, dp(5), 0, dp(5))
                        addView(tv(r.optString(0), 14f, MUTED), LinearLayout.LayoutParams(0, -2, 1f)); addView(tv(r.optString(1), 14f, TXT, true).apply { gravity = Gravity.END }, LinearLayout.LayoutParams(0, -2, 1.2f)) }) }
                parent.addView(box, lp(0, 12))
            }
            "list" -> {
                if (b.optString("title").isNotEmpty()) parent.addView(pillTitle(b.optString("title"), 14f), lp(8, 8))
                val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; background = framedBg(16); setPadding(dp(2), dp(2), dp(2), dp(2)) }
                val items = b.optJSONArray("items") ?: JSONArray()
                for (i in 0 until items.length()) {
                    val it = items.getJSONObject(i)
                    val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(dp(14), dp(13), dp(14), dp(13)) }
                    val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
                    col.addView(tv(it.optString("title"), 15f)); if (it.optString("sub").isNotEmpty()) col.addView(tv(it.optString("sub"), 12.5f, MUTED))
                    row.addView(col, LinearLayout.LayoutParams(0, -2, 1f))
                    if (it.optString("right").isNotEmpty()) row.addView(tv(it.optString("right"), 14f, ACC2, true))
                    val act = it.optJSONObject("action"); if (act != null) { row.addView(tv("›", 22f, MUTED).apply { setPadding(dp(8), 0, 0, 0) }); row.setOnClickListener { perform(act) } }
                    box.addView(row)
                    if (i < items.length() - 1) box.addView(View(this).apply { setBackgroundColor(LINE) }, LinearLayout.LayoutParams(-1, 1))
                }
                parent.addView(box, lp(0, 12))
            }
            "image" -> { val u = b.optString("url"); parent.addView(ImageView(this).apply { scaleType = ImageView.ScaleType.FIT_CENTER; adjustViewBounds = true; background = bg(Color.parseColor("#0B0F1F"), 12); Img.load(this, u); setOnClickListener { openViewer(listOf(u), 0) } }, lp(0, 12)) }
            "gallery" -> parent.addView(makeGallery(strList(b.optJSONArray("images")), b.optDouble("ratio", 0.75).toFloat()), lp(0, 12))
            "video" -> addVideo(parent, b)
            "channels" -> addChannels(parent, b.getJSONArray("items"))
            "songs" -> addSongs(parent, b.getJSONArray("items"))
            "weather_hero" -> addWeatherHero(parent, b)
            "grid" -> addGrid(parent, b)
            "hscroll" -> {
                val hs = HorizontalScrollView(this).apply { isHorizontalScrollBarEnabled = false }
                val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; setPadding(dp(6), dp(10), dp(6), dp(10)) }
                val items = b.optJSONArray("items") ?: JSONArray()
                for (i in 0 until items.length()) { val it = items.getJSONObject(i)
                    row.addView(LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER; setPadding(dp(10), 0, dp(10), 0)
                        addView(tv(it.optString("time"), 12f, MUTED).apply { gravity = Gravity.CENTER }); addView(tv(it.optString("icon"), 24f).apply { gravity = Gravity.CENTER })
                        addView(tv(it.optString("temp"), 15f, TXT, true).apply { gravity = Gravity.CENTER }); addView(tv(it.optString("pop"), 11f, MUTED).apply { gravity = Gravity.CENTER }) }, LinearLayout.LayoutParams(dp(62), -2)) }
                hs.addView(row)
                val box = FrameLayout(this).apply { background = framedBg(16); setPadding(dp(2), dp(2), dp(2), dp(2)) }; box.addView(hs)
                parent.addView(box, lp(0, 12))
            }
            "dayrows" -> {
                val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; background = framedBg(16); setPadding(dp(2), dp(2), dp(2), dp(2)) }
                val items = b.optJSONArray("items") ?: JSONArray()
                for (i in 0 until items.length()) { val it = items.getJSONObject(i)
                    val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(dp(12), dp(10), dp(10), dp(10)) }
                    val c1 = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }; c1.addView(tv(it.optString("day"), 15f, TXT, true)); c1.addView(tv(it.optString("date"), 11.5f, MUTED))
                    val c2 = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER }; c2.addView(tv(it.optString("icon"), 22f).apply { gravity = Gravity.CENTER }); c2.addView(tv(it.optString("text"), 10.5f, MUTED).apply { gravity = Gravity.CENTER })
                    val c4 = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.END }; c4.addView(tv(it.optString("hi"), 16f, TXT, true).apply { gravity = Gravity.END }); c4.addView(tv(it.optString("lo"), 13f, MUTED).apply { gravity = Gravity.END })
                    row.addView(c1, LinearLayout.LayoutParams(0, -2, 1f)); row.addView(c2, LinearLayout.LayoutParams(0, -2, 1.4f)); row.addView(tv(it.optString("pop"), 12f, ACC2), LinearLayout.LayoutParams(dp(50), -2)); row.addView(c4, LinearLayout.LayoutParams(dp(46), -2))
                    row.addView(tv("›", 20f, MUTED).apply { setPadding(dp(6), 0, 0, 0) })
                    val act = it.optJSONObject("action"); if (act != null) row.setOnClickListener { perform(act) }
                    box.addView(row); if (i < items.length() - 1) box.addView(View(this).apply { setBackgroundColor(LINE) }, LinearLayout.LayoutParams(-1, 1))
                }
                parent.addView(box, lp(0, 12))
            }
            "bars" -> {
                val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; background = framedBg(16); setPadding(dp(14), dp(10), dp(14), dp(10)) }
                val items = b.optJSONArray("items") ?: JSONArray()
                for (i in 0 until items.length()) { val it = items.getJSONObject(i)
                    val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(0, dp(6), 0, dp(6)) }
                    val l = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }; l.addView(tv(it.optString("label"), 13f)); l.addView(tv(it.optString("sub"), 10.5f, MUTED))
                    val pct = it.optInt("pct", 0).coerceIn(2, 100); val col = when (it.optString("level")) { "hi" -> RED; "mid" -> AMBER; else -> GREEN }
                    val track = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; background = bg(Color.parseColor("#0E1220"), 6) }
                    track.addView(View(this).apply { background = bg(col, 6) }, LinearLayout.LayoutParams(0, dp(9), pct.toFloat())); track.addView(View(this), LinearLayout.LayoutParams(0, dp(9), (100 - pct).toFloat()))
                    row.addView(l, LinearLayout.LayoutParams(dp(92), -2)); row.addView(track, LinearLayout.LayoutParams(0, dp(9), 1f)); row.addView(tv(it.optString("text"), 12.5f, TXT, true).apply { gravity = Gravity.END }, LinearLayout.LayoutParams(dp(78), -2))
                    box.addView(row)
                }
                parent.addView(box, lp(0, 12))
            }
            "copyfield" -> {
                val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; background = bg(CARD, 12, ACC); setPadding(dp(14), dp(10), dp(14), dp(10)) }
                box.addView(tv(b.optString("label"), 12f, MUTED)); box.addView(tv(b.optString("value"), 14f, TXT, true).apply { setTextIsSelectable(true) })
                box.addView(tv(S.t("copy"), 13f, ACC2, true).apply { setPadding(0, dp(6), 0, 0); setOnClickListener { perform(JSONObject().put("a", "copy").put("text", b.optString("value"))) } })
                parent.addView(box, lp(0, 10))
            }
            "qr" -> parent.addView(tv(b.optString("value"), 13f, MUTED), lp(0, 10))
            "divider" -> parent.addView(View(this).apply { setBackgroundColor(LINE) }, LinearLayout.LayoutParams(-1, 1).apply { setMargins(0, dp(8), 0, dp(8)) })
            "spacer" -> parent.addView(View(this), LinearLayout.LayoutParams(-1, dp(b.optInt("h", 12))))
            "chips" -> {
                val hs = HorizontalScrollView(this).apply { isHorizontalScrollBarEnabled = false }
                val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
                val items = b.optJSONArray("items") ?: JSONArray()
                for (i in 0 until items.length()) { val it = items.getJSONObject(i); val act = it.optJSONObject("action")
                    row.addView(tv(it.optString("label"), 14f).apply { background = bg(CARD, 20, LINE); setPadding(dp(14), dp(8), dp(14), dp(8)); setOnClickListener { perform(act) } }, LinearLayout.LayoutParams(-2, -2).apply { setMargins(0, 0, dp(8), 0) }) }
                hs.addView(row); parent.addView(hs, lp(0, 12))
            }
            "bubble" -> {
                val mine = b.optBoolean("mine")
                val bub = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; background = if (mine) GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(ACC, Color.parseColor("#4B3FC7"))).apply { cornerRadius = dp(16).toFloat() } else bg(CARD, 16, LINE); setPadding(dp(12), dp(8), dp(12), dp(8)) }
                bub.addView(tv(b.optString("text"), 14.5f)); if (b.optString("time").isNotEmpty()) bub.addView(tv(b.optString("time"), 11f, if (mine) Color.parseColor("#DAD6FF") else MUTED))
                parent.addView(bub, LinearLayout.LayoutParams(-2, -2).apply { gravity = if (mine) Gravity.END else Gravity.START; setMargins(if (mine) dp(48) else 0, dp(2), if (mine) 0 else dp(30), dp(6)) })
            }
            "form" -> addForm(parent, b)
        }
    }

    /** სექციის სათაური „წრეში“ (მომრგვალებული ჩარჩო) */
    private fun pillTitle(text: String, size: Float): View = LinearLayout(this).apply {
        orientation = LinearLayout.HORIZONTAL
        addView(TextView(this@MainActivity).apply { this.text = text; textSize = size; setTextColor(ACC2); typeface = Typeface.DEFAULT_BOLD; setPadding(dp(16), dp(6), dp(16), dp(6))
            background = bg(Color.argb(28, 0, 217, 192), 22, ACC2) }, LinearLayout.LayoutParams(-2, -2))
    }

    private fun strList(a: JSONArray?): List<String> { val l = ArrayList<String>(); if (a != null) for (i in 0 until a.length()) l.add(a.optString(i)); return l }

    // ---------- ბარათი (ფოტო-გალერეით) ----------
    private fun addCard(parent: LinearLayout, b: JSONObject) {
        val urls = strList(b.optJSONArray("images"))
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; background = framedBg(16); setPadding(dp(2), dp(2), dp(2), dp(2)) }
        if (urls.isNotEmpty()) box.addView(makeGallery(urls, b.optDouble("ratio", 0.75).toFloat()), LinearLayout.LayoutParams(-1, -2))
        else if (b.optString("image").isNotEmpty()) {
            val fit = b.optBoolean("fit")
            box.addView(ImageView(this).apply { scaleType = if (fit) ImageView.ScaleType.FIT_CENTER else ImageView.ScaleType.CENTER_CROP; setBackgroundColor(Color.parseColor("#0B0F1F")); Img.load(this, b.getString("image")) }, LinearLayout.LayoutParams(-1, dp(if (fit) 200 else 170)))
        }
        val inner = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(14), dp(12), dp(14), dp(12)) }
        val head = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        head.addView(tv(b.optString("title"), 16f, TXT, true), LinearLayout.LayoutParams(0, -2, 1f))
        if (b.optString("price").isNotEmpty()) {
            val pc = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.END }
            pc.addView(tv(b.optString("price"), 17f, ACC2, true).apply { gravity = Gravity.END })
            if (b.optString("old_price").isNotEmpty()) pc.addView(tv(b.optString("old_price"), 12f, MUTED).apply { paintFlags = paintFlags or android.graphics.Paint.STRIKE_THRU_TEXT_FLAG; gravity = Gravity.END })
            head.addView(pc)
        }
        inner.addView(head)
        val lines = b.optJSONArray("lines"); if (lines != null) for (i in 0 until lines.length()) { val l = lines.optString(i); if (l.isNotEmpty()) inner.addView(tv(l, 13.5f, MUTED).apply { setPadding(0, dp(4), 0, 0) }) }
        if (b.optString("badge").isNotEmpty()) inner.addView(tv(b.optString("badge"), 12f, ACC2, true).apply { setPadding(0, dp(8), 0, 0) })
        box.addView(inner)
        val act = b.optJSONObject("action"); if (act != null) { inner.setOnClickListener { perform(act) }; if (urls.isEmpty()) box.setOnClickListener { perform(act) } }
        roundClip(box, 16)
        parent.addView(box, lp(0, 12))
    }

    // ---------- გალერეა: სლაიდშოუ (გადაფურცლვა) + შეხებით გადიდება ----------
    private fun makeGallery(urls: List<String>, ratio: Float): View {
        val w = resources.displayMetrics.widthPixels - dp(32)
        val h = Math.min((w / ratio).toInt(), dp(460))
        val wrap = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(Color.parseColor("#0B0F1F")) }
        val pager = ViewPager(this); pager.id = View.generateViewId()
        pager.adapter = ImagePagerAdapter(this, urls, false) { pos -> openViewer(urls, pos) }
        wrap.addView(pager, LinearLayout.LayoutParams(-1, h))
        if (urls.size > 1) {
            val dots = TextView(this).apply { gravity = Gravity.CENTER; textSize = 13f; setTextColor(ACC2); setPadding(0, dp(4), 0, dp(4)) }
            val upd = { p: Int -> dots.text = (0 until urls.size).joinToString(" ") { if (it == p) "●" else "○" } }
            upd(0)
            pager.addOnPageChangeListener(object : ViewPager.SimpleOnPageChangeListener() { override fun onPageSelected(position: Int) { upd(position) } })
            wrap.addView(dots, LinearLayout.LayoutParams(-1, -2))
        }
        return wrap
    }

    private fun openViewer(urls: List<String>, start: Int) {
        val d = Dialog(this, android.R.style.Theme_Black_NoTitleBar_Fullscreen)
        val fl = FrameLayout(this).apply { setBackgroundColor(Color.BLACK) }
        val pager = ViewPager(this); pager.id = View.generateViewId()
        pager.adapter = ImagePagerAdapter(this, urls, true) { }
        pager.currentItem = start
        fl.addView(pager, FrameLayout.LayoutParams(-1, -1))
        val cnt = TextView(this).apply { setTextColor(Color.WHITE); textSize = 15f; setPadding(dp(16), dp(18), dp(16), dp(8)); text = if (urls.size > 1) "${start + 1} / ${urls.size}" else "" }
        fl.addView(cnt, FrameLayout.LayoutParams(-2, -2, Gravity.TOP or Gravity.START))
        pager.addOnPageChangeListener(object : ViewPager.SimpleOnPageChangeListener() { override fun onPageSelected(position: Int) { cnt.text = "${position + 1} / ${urls.size}" } })
        val x = TextView(this).apply { text = "✕"; textSize = 26f; setTextColor(Color.WHITE); gravity = Gravity.CENTER; setPadding(dp(16), dp(10), dp(16), dp(10)); setOnClickListener { d.dismiss() } }
        fl.addView(x, FrameLayout.LayoutParams(-2, -2, Gravity.TOP or Gravity.END))
        d.setContentView(fl); d.show()
    }

    // ---------- ვიდეო ----------
    private fun addVideo(parent: LinearLayout, b: JSONObject) {
        val url = b.optString("url"); val kind = b.optString("kind"); val thumb = b.optString("thumb"); val ttl = b.optString("title")
        val w = resources.displayMetrics.widthPixels - dp(28)
        val h = if (ttl.isNotEmpty()) (w * 0.5f).toInt() else (w * 9f / 16f).toInt()
        val box = FrameLayout(this).apply { setBackgroundColor(Color.parseColor("#0B0F1F")); setOnClickListener { playVideo(url, kind) } }
        val iv = ImageView(this).apply { scaleType = ImageView.ScaleType.CENTER_CROP }
        box.addView(iv, FrameLayout.LayoutParams(-1, -1))
        if (thumb.isNotEmpty()) Img.load(iv, thumb, 900)
        box.addView(TextView(this).apply { text = "▶"; textSize = 24f; setTextColor(Color.WHITE); gravity = Gravity.CENTER; background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(Color.argb(215, 229, 72, 77)) } }, FrameLayout.LayoutParams(dp(60), dp(60), Gravity.CENTER))
        if (ttl.isNotEmpty()) box.addView(tv(ttl, 13f).apply { setBackgroundColor(Color.argb(160, 0, 0, 0)); setPadding(dp(10), dp(6), dp(10), dp(6)); maxLines = 2 }, FrameLayout.LayoutParams(-1, -2, Gravity.BOTTOM))
        roundClip(box, 14)
        parent.addView(box, LinearLayout.LayoutParams(-1, h).apply { setMargins(0, 0, 0, dp(12)) })
    }

    private fun playVideo(url: String, kind: String) {
        if (kind == "file") {
            val d = Dialog(this, android.R.style.Theme_Black_NoTitleBar_Fullscreen)
            val fl = FrameLayout(this).apply { setBackgroundColor(Color.BLACK) }
            val vv = VideoView(this)
            fl.addView(vv, FrameLayout.LayoutParams(-1, -1, Gravity.CENTER))
            val mc = MediaController(this); mc.setAnchorView(vv); vv.setMediaController(mc)
            vv.setOnErrorListener { _, _, _ -> toast(S.t("play_fail")); d.dismiss(); true }
            vv.setVideoURI(Uri.parse(url)); vv.setOnPreparedListener { it.start() }
            val x = TextView(this).apply { text = "✕"; textSize = 26f; setTextColor(Color.WHITE); setPadding(dp(16), dp(10), dp(16), dp(10)); setOnClickListener { d.dismiss() } }
            fl.addView(x, FrameLayout.LayoutParams(-2, -2, Gravity.TOP or Gravity.END))
            d.setOnDismissListener { try { vv.stopPlayback() } catch (e: Exception) { } }
            d.setContentView(fl); d.show()
        } else perform(JSONObject().put("a", "url").put("url", url))
    }

    // ---------- არხების სია: ნომერი + ლოგო + სახელი (საიტის მსგავსად) ----------
    private fun addChannels(parent: LinearLayout, items: JSONArray) {
        val all = ArrayList<JSONObject>(); for (i in 0 until items.length()) all.add(items.getJSONObject(i))
        val search = EditText(this).apply {
            hint = S.t("search_ch"); setHintTextColor(Color.parseColor("#59638C")); setTextColor(TXT); textSize = 15f
            background = bg(CARD, 12, LINE); setPadding(dp(12), dp(10), dp(12), dp(10)); inputType = InputType.TYPE_CLASS_TEXT; isSingleLine = true
        }
        parent.addView(search, lp(0, 10))
        val countTv = tv("", 13f, MUTED); parent.addView(countTv, lp(0, 6))
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; background = framedBg(16); setPadding(dp(2), dp(2), dp(2), dp(2)) }
        parent.addView(box, lp(0, 8))
        val more = button(S.t("show_more"), "secondary") { }
        parent.addView(more)
        var list: List<JSONObject> = all; var shown = 0; val page = 60
        fun addRows() {
            val end = Math.min(list.size, shown + page)
            for (i in shown until end) box.addView(channelRow(list[i]))
            shown = end
            more.visibility = if (shown < list.size) View.VISIBLE else View.GONE
        }
        fun rebuild() {
            box.removeAllViews(); shown = 0; countTv.text = "${list.size} " + S.t("channels")
            if (list.isEmpty()) box.addView(tv(S.t("nothing"), 14f, MUTED).apply { setPadding(dp(14), dp(14), dp(14), dp(14)) })
            addRows()
        }
        more.setOnClickListener { addRows() }
        search.addTextChangedListener(object : android.text.TextWatcher {
            override fun afterTextChanged(e: android.text.Editable?) {
                val q = (e?.toString() ?: "").trim().lowercase()
                list = if (q.isEmpty()) all else all.filter { it.optString("name").lowercase().contains(q) }
                rebuild()
            }
            override fun beforeTextChanged(s: CharSequence?, st: Int, c: Int, a: Int) {}
            override fun onTextChanged(s: CharSequence?, st: Int, b: Int, c: Int) {}
        })
        rebuild()
    }

    private fun tile(name: String): TextView {
        val words = name.replace(Regex("[^\\p{L}\\p{N}\\s]"), " ").trim().split(Regex("\\s+")).filter { it.isNotEmpty() }
        val ini = (if (words.size > 1) words[0].take(1) + words[1].take(1) else name.filter { it.isLetterOrDigit() }.take(2)).uppercase().ifEmpty { "TV" }
        var h = 0; for (ch in name) h = (h * 31 + ch.code) % 360
        return TextView(this).apply { text = ini; textSize = 14f; setTextColor(Color.WHITE); typeface = Typeface.DEFAULT_BOLD; gravity = Gravity.CENTER; background = bg(Color.HSVToColor(floatArrayOf(h.toFloat(), 0.42f, 0.46f)), 10) }
    }

    private fun channelRow(c: JSONObject): View {
        val name = c.optString("name")
        val wrap = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(dp(8), dp(7), dp(12), dp(7)) }
        row.addView(tv(c.optInt("n").toString(), 13f, ACC2, true).apply { gravity = Gravity.CENTER }, LinearLayout.LayoutParams(dp(38), -2))
        val logoBox = FrameLayout(this)
        val showTile = { logoBox.removeAllViews(); logoBox.addView(tile(name), FrameLayout.LayoutParams(-1, -1)) }
        val logo = c.optString("logo")
        if (logo.isEmpty()) showTile() else {
            val iv = ImageView(this).apply { scaleType = ImageView.ScaleType.FIT_CENTER; setPadding(dp(4), dp(4), dp(4), dp(4)); background = bg(Color.parseColor("#0B0F1F"), 10) }
            logoBox.addView(iv, FrameLayout.LayoutParams(-1, -1)); Img.load(iv, logo, 220) { showTile() }
        }
        row.addView(logoBox, LinearLayout.LayoutParams(dp(46), dp(46)).apply { setMargins(0, 0, dp(12), 0) })
        row.addView(tv(name, 15f), LinearLayout.LayoutParams(0, -2, 1f))
        if (c.optString("url").isNotEmpty()) { row.addView(tv("▶", 16f, ACC2, true).apply { setPadding(dp(8), 0, 0, 0) }); row.setOnClickListener { playStream(c.optString("url"), name) } }
        wrap.addView(row); wrap.addView(View(this).apply { setBackgroundColor(LINE) }, LinearLayout.LayoutParams(-1, 1))
        return wrap
    }

    // ---------- ამინდი ----------
    private fun addWeatherHero(parent: LinearLayout, b: JSONObject) {
        val cols = when (b.optString("theme")) {
            "sun" -> intArrayOf(Color.parseColor("#1E88E5"), Color.parseColor("#64B5F6")); "night" -> intArrayOf(Color.parseColor("#0D1B3D"), Color.parseColor("#2A3F7A"))
            "rain" -> intArrayOf(Color.parseColor("#2C3E50"), Color.parseColor("#4B6584")); "storm" -> intArrayOf(Color.parseColor("#1F2023"), Color.parseColor("#4A4D55"))
            "snow" -> intArrayOf(Color.parseColor("#6D8197"), Color.parseColor("#B7C7D6")); "fog" -> intArrayOf(Color.parseColor("#59656F"), Color.parseColor("#9AA5AF"))
            else -> intArrayOf(Color.parseColor("#3E4A63"), Color.parseColor("#7384A3")) }
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; background = GradientDrawable(GradientDrawable.Orientation.TL_BR, cols).apply { cornerRadius = dp(20).toFloat() }; setPadding(dp(18), dp(18), dp(18), dp(18)) }
        box.addView(tv(b.optString("city"), 24f, Color.WHITE, true))
        if (b.optString("sub").isNotEmpty()) box.addView(tv(b.optString("sub"), 13f, Color.parseColor("#E8EEF7")))
        box.addView(tv(b.optString("date"), 13f, Color.parseColor("#E8EEF7")))
        val mid = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(0, dp(8), 0, dp(4)) }
        mid.addView(tv(b.optString("icon"), 54f)); mid.addView(tv(b.optString("temp"), 60f, Color.WHITE, true).apply { setPadding(dp(10), 0, 0, 0) })
        box.addView(mid)
        box.addView(tv(b.optString("desc"), 15f, Color.WHITE)); box.addView(tv(b.optString("range"), 14f, Color.parseColor("#E8EEF7")).apply { setPadding(0, dp(4), 0, 0) })
        parent.addView(box, lp(0, 12))
    }

    private fun addGrid(parent: LinearLayout, b: JSONObject) {
        val items = b.optJSONArray("items") ?: JSONArray(); val cols = b.optInt("cols", 2).coerceAtLeast(1); val compact = b.optBoolean("compact")
        var i = 0
        while (i < items.length()) {
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            for (k in 0 until cols) {
                val idx = i + k
                if (idx < items.length()) row.addView(gridCell(items.getJSONObject(idx), cols, compact), LinearLayout.LayoutParams(0, -2, 1f).apply { setMargins(dp(3), dp(3), dp(3), dp(3)) })
                else row.addView(View(this), LinearLayout.LayoutParams(0, 1, 1f))
            }
            parent.addView(row, LinearLayout.LayoutParams(-1, -2)); i += cols
        }
        parent.addView(View(this), LinearLayout.LayoutParams(-1, dp(8)))
    }

    private fun gridCell(it: JSONObject, cols: Int, compact: Boolean): View {
        val cell = LinearLayout(this).apply { background = framedBg(14) }
        if (cols >= 3) {
            cell.orientation = LinearLayout.VERTICAL; cell.gravity = Gravity.CENTER
            cell.addView(tv(it.optString("icon"), 24f).apply { gravity = Gravity.CENTER }); cell.addView(tv(it.optString("label"), 11f, MUTED).apply { gravity = Gravity.CENTER; maxLines = 2 })
            cell.setPadding(dp(4), dp(12), dp(4), dp(12))
        } else if (compact) {
            cell.orientation = LinearLayout.HORIZONTAL; cell.gravity = Gravity.CENTER_VERTICAL
            cell.addView(tv(it.optString("icon"), 20f)); cell.addView(tv(it.optString("label"), 13.5f).apply { setPadding(dp(8), 0, 0, 0); maxLines = 1 }, LinearLayout.LayoutParams(0, -2, 1f)); cell.addView(tv(it.optString("value"), 15f, ACC2, true))
            cell.setPadding(dp(12), dp(11), dp(12), dp(11))
        } else {
            cell.orientation = LinearLayout.VERTICAL
            val head = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
            head.addView(tv(it.optString("icon"), 15f)); head.addView(tv(it.optString("label"), 12.5f, MUTED).apply { setPadding(dp(6), 0, 0, 0) })
            cell.addView(head); cell.addView(tv(it.optString("value"), 18f, TXT, true).apply { setPadding(0, dp(4), 0, 0) })
            if (it.optString("sub").isNotEmpty()) cell.addView(tv(it.optString("sub"), 10.5f, MUTED))
            cell.setPadding(dp(12), dp(10), dp(12), dp(10))
        }
        val act = it.optJSONObject("action"); if (act != null) cell.setOnClickListener { perform(act) }
        return cell
    }

    // ---------------- ფორმა ----------------
    private fun addForm(parent: LinearLayout, b: JSONObject) {
        val getters = LinkedHashMap<String, () -> String>()
        val files = HashMap<String, Uri?>()
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; background = framedBg(16); setPadding(dp(16), dp(16), dp(16), dp(10)) }
        val fields = b.getJSONArray("fields")
        for (i in 0 until fields.length()) {
            val f = fields.getJSONObject(i); val name = f.getString("name"); val type = f.optString("type"); val label = f.optString("label")
            if (type == "hidden") { val v = f.optString("value"); getters[name] = { v }; continue }
            if (type == "actionbtn") {
                val uses = f.optJSONArray("uses") ?: JSONArray()
                val btn = button(f.optString("btn"), "secondary") { }
                btn.setOnClickListener {
                    val m = HashMap<String, String>(); for (u in 0 until uses.length()) { val k = uses.getString(u); m[k] = getters[k]?.invoke() ?: "" }
                    btn.isEnabled = false; doAct(f.getString("act"), m, emptyList()) { btn.isEnabled = true }
                }
                box.addView(btn); continue
            }
            if (label.isNotEmpty() && type != "checkbox") box.addView(tv(label, 13f, MUTED).apply { setPadding(0, dp(4), 0, dp(4)) })
            when (type) {
                "select" -> {
                    val opts = f.optJSONArray("options") ?: JSONArray(); val vals = ArrayList<String>(); val labs = ArrayList<String>()
                    for (k in 0 until opts.length()) { val o = opts.getJSONArray(k); vals.add(o.optString(0)); labs.add(o.optString(1)) }
                    val sp = Spinner(this); sp.adapter = object : ArrayAdapter<String>(this, android.R.layout.simple_spinner_dropdown_item, labs) {
                        override fun getView(p: Int, c: View?, g: ViewGroup): View = (super.getView(p, c, g) as TextView).apply { setTextColor(TXT) }
                    }
                    val idx = vals.indexOf(f.optString("value")); if (idx >= 0) sp.setSelection(idx)
                    sp.background = bg(BG2, 10, LINE)
                    box.addView(sp, lp(0, 10)); getters[name] = { if (vals.isEmpty()) "" else vals[sp.selectedItemPosition] }
                }
                "checkbox" -> { val cb = CheckBox(this).apply { text = label; setTextColor(TXT); isChecked = f.optString("value") == "1" }; box.addView(cb, lp(0, 8)); getters[name] = { if (cb.isChecked) "1" else "0" } }
                "file" -> {
                    val info = tv(S.t("no_file"), 13f, MUTED)
                    box.addView(button(S.t("pick_file"), "secondary") {
                        pickTarget = { uri -> files[name] = uri; info.text = S.t("file_ok"); info.setTextColor(GREEN) }
                        val i = Intent(Intent.ACTION_GET_CONTENT).setType("*/*").addCategory(Intent.CATEGORY_OPENABLE).putExtra(Intent.EXTRA_MIME_TYPES, arrayOf("image/*", "application/pdf"))
                        startActivityForResult(Intent.createChooser(i, S.t("pick_receipt")), REQ_PICK)
                    }); box.addView(info, lp(0, 10)); getters[name] = { if (files[name] != null) "1" else "" }
                }
                else -> {
                    val et = EditText(this).apply {
                        hint = f.optString("placeholder"); setHintTextColor(Color.parseColor("#59638C")); setTextColor(TXT); textSize = 15f; background = bg(BG2, 10, LINE); setPadding(dp(12), dp(11), dp(12), dp(11))
                        setText(f.optString("value"))
                        inputType = when (type) { "email" -> InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_EMAIL_ADDRESS; "password" -> InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
                            "phone" -> InputType.TYPE_CLASS_NUMBER; "number" -> InputType.TYPE_CLASS_NUMBER; "textarea" -> InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE or InputType.TYPE_TEXT_FLAG_CAP_SENTENCES; else -> InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_CAP_SENTENCES }
                        if (type == "textarea") { minLines = 3; gravity = Gravity.TOP }
                    }
                    box.addView(et, lp(0, 6)); getters[name] = { et.text.toString().trim() }
                    fieldViews.add { et.text.isNotEmpty() && type != "hidden" }
                    if (f.optString("hint").isNotEmpty()) box.addView(tv(f.optString("hint"), 11.5f, MUTED), lp(0, 8))
                }
            }
        }
        val sub = b.getJSONObject("submit")
        val btn = button(sub.optString("label"), "primary") { }
        btn.setOnClickListener {
            val m = HashMap<String, String>()
            for ((k, g) in getters) m[k] = g()
            sub.optJSONObject("f")?.let { o -> o.keys().forEach { k -> m[k] = o.optString(k) } }
            // ფაილის ველების მნიშვნელობები (ბაიტები კი multipart-ით მიდის)
            val up = ArrayList<UploadFile>(); for ((k, u) in files) if (u != null) { up.add(UploadFile(k, u)); m.remove(k) }
            (currentFocus)?.let { (getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager).hideSoftInputFromWindow(it.windowToken, 0) }
            btn.isEnabled = false; doAct(sub.getString("act"), m, up) { btn.isEnabled = true }
        }
        box.addView(btn, lp(6, 6))
        parent.addView(box, lp(0, 14))
    }

    // ---------------- ლოკაცია / ფაილი ----------------
    private fun hasLoc() = ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED || ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED
    @Suppress("MissingPermission")
    private fun lastLocation(): Pair<Double, Double>? {
        if (!hasLoc()) return null
        return try {
            val lm = getSystemService(Context.LOCATION_SERVICE) as LocationManager
            var best: android.location.Location? = null
            for (p in lm.getProviders(true)) { val l = lm.getLastKnownLocation(p) ?: continue; if (best == null || l.time > best.time) best = l }
            best?.let { Pair(it.latitude, it.longitude) }
        } catch (e: Exception) { null }
    }
    private fun locateAndReload() {
        if (!hasLoc()) { pendingLocate = true; ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION), REQ_LOC); return }
        toast(S.t("locating"))
        val l = lastLocation()
        if (l == null) { toast(S.t("no_loc")); return }
        val st = stacks[tab] ?: return
        if (st.isNotEmpty() && st.last().id == "weather") st.removeAt(st.size - 1)
        st.add(Frame("weather", mapOf("lat" to l.first.toString(), "lon" to l.second.toString()))); reload()
    }
    override fun onRequestPermissionsResult(code: Int, perms: Array<out String>, res: IntArray) {
        super.onRequestPermissionsResult(code, perms, res)
        if (code == REQ_LOC && hasLoc()) { if (pendingLocate) { pendingLocate = false; locateAndReload() } else if (cur()?.id == "weather") reload() }
    }
    @Deprecated("Deprecated in Java")
    override fun onActivityResult(req: Int, res: Int, data: Intent?) {
        super.onActivityResult(req, res, data)
        if (req == REQ_PICK && res == Activity.RESULT_OK) data?.data?.let { pickTarget?.invoke(it) }
    }

    // ---------- უფასო ტელევიზია: ჩაშენებული ფლეიერი (ExoPlayer) ----------
    private var exo: androidx.media3.exoplayer.ExoPlayer? = null
    private fun playStream(url: String, name: String) {
        val d = Dialog(this, android.R.style.Theme_Black_NoTitleBar_Fullscreen)
        val fl = FrameLayout(this).apply { setBackgroundColor(Color.BLACK) }
        val dsf = androidx.media3.datasource.DefaultHttpDataSource.Factory().setAllowCrossProtocolRedirects(true).setConnectTimeoutMs(12000).setReadTimeoutMs(20000)
            .setUserAgent("Mozilla/5.0 (Linux; Android 13) AppleWebKit/537.36 Chrome/124 Mobile Safari/537.36")
        val player = androidx.media3.exoplayer.ExoPlayer.Builder(this).setMediaSourceFactory(androidx.media3.exoplayer.source.DefaultMediaSourceFactory(dsf)).build(); exo = player
        val pv = androidx.media3.ui.PlayerView(this).apply { this.player = player; useController = true; setShowBuffering(androidx.media3.ui.PlayerView.SHOW_BUFFERING_ALWAYS) }
        fl.addView(pv, FrameLayout.LayoutParams(-1, -1))
        // ცდები: პირდაპირ → საიტის პროქსი → ნედლი MPEG-TS (პირდაპირ / პროქსი)
        val proxy = Api.BASE + "tv/proxy.php?u=" + java.net.URLEncoder.encode(url, "UTF-8")
        val attempts = listOf(url to false, proxy to false, url to true, proxy to true)
        var ai = 0
        fun start() {
            val (u, ts) = attempts[ai]
            val mi = androidx.media3.common.MediaItem.Builder().setUri(Uri.parse(u)).apply { if (ts) setMimeType(androidx.media3.common.MimeTypes.VIDEO_MP2T) }.build()
            player.setMediaItem(mi); player.prepare(); player.playWhenReady = true
        }
        player.addListener(object : androidx.media3.common.Player.Listener {
            override fun onPlayerError(error: androidx.media3.common.PlaybackException) { if (ai < attempts.size - 1) { ai++; start() } else toast(S.t("play_fail")) }
        })
        start()
        fl.addView(tv(name, 15f, Color.WHITE, true).apply { setPadding(dp(16), dp(14), dp(60), dp(8)); maxLines = 1 }, FrameLayout.LayoutParams(-1, -2, Gravity.TOP or Gravity.START))
        fl.addView(TextView(this).apply { text = "✕"; textSize = 26f; setTextColor(Color.WHITE); setPadding(dp(16), dp(10), dp(16), dp(10)); setOnClickListener { d.dismiss() } }, FrameLayout.LayoutParams(-2, -2, Gravity.TOP or Gravity.END))
        d.setOnDismissListener { try { player.release() } catch (e: Exception) { }; exo = null }
        d.setContentView(fl); d.show()
        d.window?.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
    }

    // ---------- სიმღერები: ჩაშენებული ფლეიერი (საიტის მსგავსად, აპლიკაციიდან გაუსვლელად) ----------
    private fun addSongs(parent: LinearLayout, items: JSONArray) {
        val list = ArrayList<JSONObject>(); for (i in 0 until items.length()) list.add(items.getJSONObject(i))
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; background = framedBg(16); setPadding(dp(2), dp(2), dp(2), dp(2)) }
        for ((i, it) in list.withIndex()) {
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(dp(10), dp(8), dp(12), dp(8)); setOnClickListener { openSongPlayer(list, i) } }
            val iv = ImageView(this).apply { scaleType = ImageView.ScaleType.CENTER_CROP; setBackgroundColor(Color.parseColor("#0B0F1F")) }; roundClip(iv, 8); Img.load(iv, it.optString("thumb"), 400)
            row.addView(iv, LinearLayout.LayoutParams(dp(96), dp(54)).apply { setMargins(0, 0, dp(12), 0) })
            val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
            col.addView(tv(it.optString("title"), 14f).apply { maxLines = 2; ellipsize = android.text.TextUtils.TruncateAt.END }); if (it.optString("channel").isNotEmpty()) col.addView(tv(it.optString("channel"), 11.5f, MUTED).apply { maxLines = 1 })
            row.addView(col, LinearLayout.LayoutParams(0, -2, 1f))
            row.addView(tv("▶", 18f, ACC2, true).apply { setPadding(dp(10), 0, 0, 0) })
            box.addView(row); if (i < list.size - 1) box.addView(View(this).apply { setBackgroundColor(LINE) }, LinearLayout.LayoutParams(-1, 1))
        }
        parent.addView(box, lp(0, 12))
    }

    // საიტის მინი-პლეერის მსგავსი მუდმივი პლეერი: ქვედა მენიუს ზემოთ, სიმღერა გვერდებს შორის გადასვლისას არ წყდება
    private var songList: List<JSONObject> = emptyList(); private var songIdx = 0; private var songReady = false; private var songPlaying = false; private var songDur = 0.0; private var seeking = false
    private lateinit var miniTitle: TextView; private lateinit var miniThumb: ImageView; private lateinit var miniPlay: TextView; private lateinit var miniSeek: SeekBar; private lateinit var miniCur: TextView; private lateinit var miniDur: TextView

    private fun fmt(sec: Double): String { val t = sec.toInt().coerceAtLeast(0); return (t / 60).toString() + ":" + (t % 60).toString().padStart(2, '0') }
    private fun ctl(label: String, size: Float = 16f, onClick: () -> Unit) = TextView(this).apply { text = label; textSize = size; setTextColor(Color.WHITE); gravity = Gravity.CENTER; background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(Color.parseColor("#2B3245")) }; setOnClickListener { onClick() } }

    private fun buildMiniPlayer(): LinearLayout {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(Color.parseColor("#101626")); setPadding(dp(10), dp(6), dp(10), dp(6)); visibility = View.GONE }
        val r1 = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        miniThumb = ImageView(this).apply { scaleType = ImageView.ScaleType.CENTER_CROP; setBackgroundColor(Color.parseColor("#1C2540")) }; roundClip(miniThumb, 6)
        miniTitle = tv("", 13f, Color.WHITE, true).apply { maxLines = 1; ellipsize = android.text.TextUtils.TruncateAt.END }
        miniPlay = ctl("▶", 16f) { songToggle() }.apply { background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(ACC) } }
        r1.addView(miniThumb, LinearLayout.LayoutParams(dp(52), dp(36)).apply { setMargins(0, 0, dp(8), 0) })
        r1.addView(miniTitle, LinearLayout.LayoutParams(0, -2, 1f))
        r1.addView(ctl("⏮", 13f) { songStep(-1) }, LinearLayout.LayoutParams(dp(34), dp(34)).apply { setMargins(dp(4), 0, dp(4), 0) })
        r1.addView(miniPlay, LinearLayout.LayoutParams(dp(42), dp(42)))
        r1.addView(ctl("⏭", 13f) { songStep(1) }, LinearLayout.LayoutParams(dp(34), dp(34)).apply { setMargins(dp(4), 0, dp(4), 0) })
        r1.addView(ctl("✕", 13f) { songClose() }, LinearLayout.LayoutParams(dp(34), dp(34)))
        val r2 = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        miniCur = tv("0:00", 11.5f, Color.parseColor("#C9D1E6")); miniDur = tv("0:00", 11.5f, Color.parseColor("#C9D1E6"))
        miniSeek = SeekBar(this).apply { max = 1000
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(sb: SeekBar?, p: Int, fromUser: Boolean) { if (fromUser) miniCur.text = fmt(songDur * p / 1000.0) }
                override fun onStartTrackingTouch(sb: SeekBar?) { seeking = true }
                override fun onStopTrackingTouch(sb: SeekBar?) { seeking = false; songWeb?.evaluateJavascript("seek(" + (songDur * (sb?.progress ?: 0) / 1000.0) + ")", null) }
            }) }
        r2.addView(ctl("⏪", 12f) { songWeb?.evaluateJavascript("jump(-10)", null) }, LinearLayout.LayoutParams(dp(30), dp(30)))
        r2.addView(miniCur, LinearLayout.LayoutParams(dp(38), -2).apply { setMargins(dp(6), 0, 0, 0) }); r2.addView(miniSeek, LinearLayout.LayoutParams(0, -2, 1f)); r2.addView(miniDur, LinearLayout.LayoutParams(dp(38), -2))
        r2.addView(ctl("⏩", 12f) { songWeb?.evaluateJavascript("jump(10)", null) }, LinearLayout.LayoutParams(dp(30), dp(30)))
        box.addView(r1, LinearLayout.LayoutParams(-1, -2)); box.addView(r2, LinearLayout.LayoutParams(-1, -2).apply { setMargins(0, dp(4), 0, 0) })
        return box
    }

    @android.annotation.SuppressLint("SetJavaScriptEnabled")
    private fun openSongPlayer(list: List<JSONObject>, start: Int) {
        songList = list; songIdx = start
        if (songWeb == null) {
            val w = android.webkit.WebView(this)
            w.settings.javaScriptEnabled = true; w.settings.mediaPlaybackRequiresUserGesture = false; w.settings.domStorageEnabled = true
            w.webChromeClient = android.webkit.WebChromeClient()
            w.addJavascriptInterface(object {
                @android.webkit.JavascriptInterface fun ready() { main.post { songReady = true; songLoadCurrent() } }
                @android.webkit.JavascriptInterface fun tick(cur: Double, dur: Double) { main.post { songDur = dur; if (!seeking && dur > 0) { miniSeek.progress = (cur / dur * 1000).toInt(); miniCur.text = fmt(cur) }; miniDur.text = fmt(dur) } }
                @android.webkit.JavascriptInterface fun state(st: Int) { main.post { songPlaying = st == 1; miniPlay.text = if (songPlaying) "⏸" else "▶" } }
                @android.webkit.JavascriptInterface fun ended() { main.post { songStep(1) } }
                @android.webkit.JavascriptInterface fun err(code: Int) { main.post { toast(S.t("song_fail")); main.postDelayed({ songStep(1) }, 1200) } }
            }, "A")
            rootLayout.addView(w, LinearLayout.LayoutParams(1, 1))   // საიტის მსგავსად: 1×1 უხილავი ჩაშენებული YouTube პლეერი, ჩვენი საკუთარი მართვით
            songWeb = w; songReady = false
            val html = "<html><body style='margin:0;background:#000'><div id='p'></div><script src='https://www.youtube.com/iframe_api'></script><script>" +
                "var yt=null,ok=false,pend=null;function onYouTubeIframeAPIReady(){yt=new YT.Player('p',{height:'1',width:'1',playerVars:{playsinline:1,rel:0}," +
                "events:{onReady:function(){ok=true;A.ready();setInterval(function(){try{A.tick(yt.getCurrentTime()||0,yt.getDuration()||0)}catch(e){}},500)}," +
                "onStateChange:function(e){A.state(e.data);if(e.data===0)A.ended()},onError:function(e){A.err(e.data)}}})}" +
                "function go(id){if(ok)yt.loadVideoById(id)}function toggle(){var s=yt.getPlayerState();if(s===1)yt.pauseVideo();else yt.playVideo()}" +
                "function seek(t){yt.seekTo(t,true)}function jump(d){yt.seekTo(Math.max(0,yt.getCurrentTime()+d),true)}</script></body></html>"
            w.loadDataWithBaseURL(Api.BASE, html, "text/html", "utf-8", null)
        } else songLoadCurrent()
        mini.visibility = View.VISIBLE
        showMiniInfo()
    }
    private fun showMiniInfo() {
        val s = songList.getOrNull(songIdx) ?: return
        miniTitle.text = s.optString("title"); Img.load(miniThumb, s.optString("thumb"), 300); miniSeek.progress = 0; miniCur.text = "0:00"; miniDur.text = "0:00"
    }
    private fun songLoadCurrent() { if (!songReady) return; val s = songList.getOrNull(songIdx) ?: return; showMiniInfo(); songWeb?.evaluateJavascript("go('" + s.optString("sid").replace("'", "") + "')", null) }
    private fun songStep(d: Int) { val n = songIdx + d; if (n in songList.indices) { songIdx = n; songLoadCurrent() } }
    private fun songToggle() { songWeb?.evaluateJavascript("toggle()", null) }
    private fun songClose() { songWeb?.evaluateJavascript("try{yt.stopVideo()}catch(e){}", null); mini.visibility = View.GONE; songPlaying = false }

    // ---------- „ტელევიზიის ყურება“: მთავარი TELEVIZIA.STORE აპლიკაცია (ავტო-შესვლა) ან გადმოწერა ----------
    private val TV_PKG = "store.televizia.app"
    private fun openUrl(u: String) { try { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(u))) } catch (e: Exception) { toast(S.t("link_fail")) } }
    private fun openTvApp() {
        val ver = try { if (android.os.Build.VERSION.SDK_INT >= 28) packageManager.getPackageInfo(TV_PKG, 0).longVersionCode.toInt() else @Suppress("DEPRECATION") packageManager.getPackageInfo(TV_PKG, 0).versionCode } catch (e: Exception) { -1 }
        progress.visibility = View.VISIBLE
        Thread {
            val r = if (ver >= 0) Api.act("tv_handoff", emptyMap(), emptyList()) else Api.act("tv_apk", emptyMap(), emptyList())
            main.post {
                progress.visibility = View.GONE
                if (ver < 0) { toast(S.t("tv_dl")); val u = r.optString("apk"); if (u.isNotEmpty()) Installer.download(this, u, S.t("dl_tv")) else openUrl(Api.BASE); return@post }
                if (!r.optBoolean("ok")) { say(r.optString("error", S.t("error")), false); r.optJSONObject("nav")?.let { perform(it) }; return@post }
                val launch = {
                    val i = Intent(Intent.ACTION_VIEW, Uri.parse("televizia://login?code=" + r.optString("code"))).setPackage(TV_PKG).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    try { startActivity(i) } catch (e: Exception) { packageManager.getLaunchIntentForPackage(TV_PKG)?.let { startActivity(it) } }
                }
                if (ver < 116) AlertDialog.Builder(this).setMessage(S.t("tv_old")).setPositiveButton(S.t("tv_update")) { _, _ -> val u = r.optString("apk"); if (u.isNotEmpty()) Installer.download(this, u, S.t("dl_tv")) else openUrl(Api.BASE) }.setNegativeButton(S.t("tv_open")) { _, _ -> launch() }.show()
                else launch()
            }
        }.start()
    }

    // ---------- სოციალური შესვლა (ბრაუზერში, საიტის მეთოდით; აპლიკაცია თვითონ ამოწმებს დადასტურებას) ----------
    private fun startSocial(provider: String) {
        progress.visibility = View.VISIBLE
        Thread {
            val r = Api.act("social_start", mapOf("provider" to provider), emptyList())
            main.post {
                progress.visibility = View.GONE
                if (r.optBoolean("ok")) { socialCode = r.optString("code"); socialTries = 0; openUrl(r.optString("url")); main.postDelayed({ socialPoll() }, 3000) }
                else say(r.optString("error", S.t("error")), false)
            }
        }.start()
    }
    private fun socialPoll() {
        val c = socialCode ?: return
        if (++socialTries > 240) { socialCode = null; return }
        Thread {
            val r = Api.act("social_check", mapOf("code" to c), emptyList())
            main.post {
                if (socialCode != c) return@post
                if (r.optString("token").isNotEmpty()) { socialCode = null; handleAct("social_check", r) }
                else if (r.optBoolean("expired")) socialCode = null
                else main.postDelayed({ socialPoll() }, 2500)
            }
        }.start()
    }
    override fun onNewIntent(intent: Intent) { super.onNewIntent(intent); if (socialCode != null) main.post { socialPoll() } }
    override fun onResume() { super.onResume(); Installer.resume(this); if (socialCode != null) main.postDelayed({ socialPoll() }, 500) }
    override fun onDestroy() { super.onDestroy(); try { songWeb?.destroy() } catch (e: Exception) { }; notifRun?.let { main.removeCallbacks(it) } }

    // ---------- შეტყობინებები: ფონური შემოწმება (WorkManager) + აპლიკაციის გახსნისას ყოველ 45 წმ-ში ----------
    private var notifRun: Runnable? = null
    private fun startNotifWatch() {
        if (!loggedIn) return
        if (android.os.Build.VERSION.SDK_INT >= 33 && ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED)
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.POST_NOTIFICATIONS), 8803)
        Notif.schedule(this)
        notifRun?.let { main.removeCallbacks(it) }
        val run = object : Runnable { override fun run() { if (loggedIn) Thread { try { Notif.poll(applicationContext) } catch (e: Exception) { } }.start(); main.postDelayed(this, 45000) } }
        notifRun = run; main.post(run)
    }

    // ---------- აპლიკაციის შიდა განახლება ----------
    private fun checkSelfUpdate() {
        if (updateChecked) return; updateChecked = true
        val mine = try { if (android.os.Build.VERSION.SDK_INT >= 28) packageManager.getPackageInfo(packageName, 0).longVersionCode.toInt() else @Suppress("DEPRECATION") packageManager.getPackageInfo(packageName, 0).versionCode } catch (e: Exception) { Int.MAX_VALUE }
        Thread {
            val r = Api.act("app_update", emptyMap(), emptyList())
            if (r.optBoolean("ok") && r.optInt("code") > mine && r.optString("url").isNotEmpty()) main.post {
                AlertDialog.Builder(this).setTitle(S.t("upd_title")).setMessage(r.optString("name") + "\n" + r.optString("notes"))
                    .setPositiveButton(S.t("upd_dl")) { _, _ -> Installer.download(this, r.optString("url"), S.t("upd_title")) }.setNegativeButton(S.t("later"), null).show()
            }
        }.start()
    }
}
