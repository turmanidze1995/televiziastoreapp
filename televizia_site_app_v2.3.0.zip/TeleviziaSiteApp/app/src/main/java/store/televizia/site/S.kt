package store.televizia.site

/** აპლიკაციის საკუთარი ტექსტები: ka / ru / en (სერვერის ტექსტები სერვერზე ითარგმნება) */
object S {
    var lang = "ka"
    private val m = mapOf(
        "retry" to arrayOf("თავიდან ცდა", "Повторить", "Retry"),
        "error" to arrayOf("შეცდომა", "Ошибка", "Error"),
        "screen_fail" to arrayOf("ეკრანი ვერ ჩაიტვირთა", "Не удалось загрузить экран", "Could not load the screen"),
        "yes" to arrayOf("დიახ", "Да", "Yes"),
        "cancel" to arrayOf("გაუქმება", "Отмена", "Cancel"),
        "link_fail" to arrayOf("ბმული ვერ გაიხსნა", "Не удалось открыть ссылку", "Could not open the link"),
        "share" to arrayOf("გაზიარება", "Поделиться", "Share"),
        "copied" to arrayOf("დაკოპირდა", "Скопировано", "Copied"),
        "copy" to arrayOf("კოპირება", "Копировать", "Copy"),
        "no_file" to arrayOf("ფაილი არ არის არჩეული", "Файл не выбран", "No file selected"),
        "file_ok" to arrayOf("✔ არჩეულია", "✔ Выбрано", "✔ Selected"),
        "pick_file" to arrayOf("📎 ფაილის არჩევა", "📎 Выбрать файл", "📎 Choose a file"),
        "pick_receipt" to arrayOf("აირჩიეთ ქვითარი", "Выберите квитанцию", "Choose the receipt"),
        "login" to arrayOf("შესვლა", "Войти", "Sign in"),
        "register" to arrayOf("რეგისტრაცია", "Регистрация", "Register"),
        "lang_title" to arrayOf("ენა", "Язык", "Language"),
        "search_ch" to arrayOf("🔍 არხის ძებნა", "🔍 Поиск канала", "🔍 Search channels"),
        "show_more" to arrayOf("მეტის ჩვენება", "Показать ещё", "Show more"),
        "channels" to arrayOf("არხი", "каналов", "channels"),
        "nothing" to arrayOf("არხები ვერ მოიძებნა", "Каналы не найдены", "No channels found"),
        "no_loc" to arrayOf("მდებარეობა ვერ დადგინდა. ჩართეთ GPS და სცადეთ თავიდან.", "Не удалось определить местоположение. Включите GPS и повторите.", "Could not get your location. Turn on GPS and try again."),
        "locating" to arrayOf("ვადგენ მდებარეობას…", "Определяю местоположение…", "Finding your location…"),
        "close" to arrayOf("დახურვა", "Закрыть", "Close"),
        "play_fail" to arrayOf("ვიდეო ვერ ჩაირთო", "Не удалось включить видео", "Could not play the video"),
        "noconn" to arrayOf("კავშირის შეცდომა. შეამოწმეთ ინტერნეტი.", "Ошибка соединения. Проверьте интернет.", "Connection error. Check your internet."),
        "badresp" to arrayOf("სერვერის პასუხი არასწორია", "Неверный ответ сервера", "Invalid server response"),
        "back" to arrayOf("უკან", "Назад", "Back"),
        "tv_dl" to arrayOf("TELEVIZIA.STORE აპლიკაცია არ არის დაყენებული. იწყება გადმოწერა…", "Приложение TELEVIZIA.STORE не установлено. Начинается загрузка…", "The TELEVIZIA.STORE app is not installed. Download is starting…"),
        "tv_old" to arrayOf("ავტომატური შესვლისთვის საჭიროა TELEVIZIA.STORE აპლიკაციის 1.7.107 ან უფრო ახალი ვერსია.", "Для автоматического входа нужна версия приложения TELEVIZIA.STORE 1.7.107 или новее.", "Auto sign-in needs TELEVIZIA.STORE app version 1.7.107 or newer."),
        "tv_update" to arrayOf("განახლება", "Обновить", "Update"),
        "tv_open" to arrayOf("მაინც გახსნა", "Открыть всё равно", "Open anyway"),
        "allow_install" to arrayOf("ჩართეთ „ამ წყაროდან დაყენების“ ნებართვა და დაბრუნდით აპლიკაციაში", "Разрешите установку из этого источника и вернитесь в приложение", "Allow installing from this source and come back to the app"),
        "upd_title" to arrayOf("ახალი ვერსია ხელმისაწვდომია", "Доступна новая версия", "A new version is available"),
        "upd_dl" to arrayOf("გადმოწერა და დაყენება", "Скачать и установить", "Download and install"),
        "later" to arrayOf("მოგვიანებით", "Позже", "Later"),
        "dl_tv" to arrayOf("TELEVIZIA.STORE-ის გადმოწერა", "Загрузка TELEVIZIA.STORE", "Downloading TELEVIZIA.STORE"),
        "song_fail" to arrayOf("ეს სიმღერა ვერ ირთვება, გადავდივარ შემდეგზე…", "Эту песню не удаётся включить, перехожу к следующей…", "This song can't be played, skipping to the next…"),
        "song_prev" to arrayOf("წინა", "Пред.", "Prev"),
        "song_next" to arrayOf("შემდეგი", "След.", "Next"),
        "now_playing" to arrayOf("უკრავს", "Играет", "Now playing")
    )
    private fun idx() = when (lang) { "ru" -> 1; "en" -> 2; else -> 0 }
    fun t(k: String): String = m[k]?.get(idx()) ?: k
}
