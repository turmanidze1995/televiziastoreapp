plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "store.televizia.site"
    compileSdk = 34

    defaultConfig {
        applicationId = "store.televizia.site"
        minSdk = 21
        targetSdk = 34
        versionCode = 4
        versionName = "2.2.0"
    }

    // იგივე მუდმივი ხელმოწერა, რაც TELEVIZIA.STORE აპლიკაციას აქვს (ყოველი ახალი ბილდი ძველზე განახლებად დაყენდება)
    signingConfigs {
        getByName("debug") {
            storeFile = file("televizia.keystore")
            storePassword = "televizia-2026"
            keyAlias = "televizia"
            keyPassword = "televizia-2026"
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            signingConfig = signingConfigs.getByName("debug")
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
}

dependencies {
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("androidx.swiperefreshlayout:swiperefreshlayout:1.1.0")
    implementation("androidx.viewpager:viewpager:1.0.0")
    implementation("androidx.media3:media3-exoplayer:1.3.1")
    implementation("androidx.media3:media3-exoplayer-hls:1.3.1")
    implementation("androidx.media3:media3-ui:1.3.1")
}
