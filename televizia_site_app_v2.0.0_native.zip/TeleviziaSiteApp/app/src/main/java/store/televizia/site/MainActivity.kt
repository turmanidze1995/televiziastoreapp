package store.televizia.site

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.location.LocationManager
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.InputMethodManager
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout
import org.json.JSONArray
import org.json.JSONObject

/** ნატიური (WebView-ის გარეშე) საიტის აპლიკაცია: სერვერი აბრუნებს ეკრანებს (ბლოკების სიას), აპლიკაცია ხატავს ნატიურ ელემენტებს */
class MainActivity : AppCompatActivity() {

    private val BG = Color.parseColor("#0B1020"); private val CARD = Color.parseColor("#151B33"); private val LINE = Color.parseColor("#262E52")
    private val TXT = Color.WHITE; private val MUTED = Color.parseColor("#9AA4C7"); private val ACC = Color.parseColor("#6C5CE7"); private val ACC2 = Color.parseColor("#00D9C0")
    private val RED = Color.parseColor("#E5484D"); private val GREEN = Color.parseColor("#2ECC71"); private val AMBER = Color.parseColor("#F5A524")

    private val main = Handler(Looper.getMainLooper())
    private class Frame(val id: String, val params: Map<String, String>)
    private val stacks = HashMap<String, ArrayList<Frame>>()
    private var tabs = JSONArray()
    private var tab = "home"
    private var site = "TELEVIZIA"

    private lateinit var title: TextView
    private lateinit var back: TextView
    private lateinit var tabBar: LinearLayout
    private lateinit var content: LinearLayout
    private lateinit var swipe: SwipeRefreshLayout
    private lateinit var banner: TextView
    private lateinit var progress: ProgressBar
    private var gen = 0                       // მოძველებული პასუხების გამოსარიცხად
    private var refreshRunnable: Runnable? = null
    private val fieldViews = ArrayList<() -> Boolean>()   // true = ველი შევსებულია (ავტო-განახლებას აჩერებს)

    // ფაილის არჩევა
    private var pickTarget: ((Uri) -> Unit)? = null
    private val REQ_PICK = 8801; private val REQ_LOC = 8802
    private var askedLoc = false

    private fun dp(v: Int) = (v * resources.displayMetrics.density + 0.5f).toInt()
    private fun bg(color: Int, r: Int = 12, stroke: Int = 0): GradientDrawable = GradientDrawable().apply {
        setColor(color); cornerRadius = dp(r).toFloat(); if (stroke != 0) setStroke(dp(1), stroke)
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        Api.init(this)
        buildShell()
        loadBoot()
    }

    // ---------------- გარსი ----------------
    private fun buildShell() {
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(BG) }
        val top = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setBackgroundColor(Color.parseColor("#0E1430")); setPadding(dp(6), dp(8), dp(12), dp(8)) }
        back = TextView(this).apply { text = "←"; textSize = 24f; setTextColor(TXT); setPadding(dp(12), 0, dp(12), 0); visibility = View.GONE; setOnClickListener { goBack() } }
        title = TextView(this).apply { textSize = 18f; setTextColor(TXT); typeface = Typeface.DEFAULT_BOLD; setPadding(dp(10), 0, 0, 0); maxLines = 1 }
        top.addView(back); top.addView(title, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        root.addView(top, LinearLayout.LayoutParams(-1, dp(52)))

        val frame = FrameLayout(this)
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        banner = TextView(this).apply { textSize = 14f; setTextColor(Color.WHITE); setPadding(dp(14), dp(10), dp(14), dp(10)); visibility = View.GONE; setOnClickListener { visibility = View.GONE } }
        col.addView(banner, LinearLayout.LayoutParams(-1, -2))
        swipe = SwipeRefreshLayout(this)
        val sv = ScrollView(this).apply { isFillViewport = true; clipToPadding = false }
        content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(14), dp(12), dp(14), dp(24)) }
        sv.addView(content, FrameLayout.LayoutParams(-1, -2))
        swipe.addView(sv)
        swipe.setOnRefreshListener { reload() }
        col.addView(swipe, LinearLayout.LayoutParams(-1, 0, 1f))
        frame.addView(col, FrameLayout.LayoutParams(-1, -1))
        progress = ProgressBar(this).apply { visibility = View.GONE }
        frame.addView(progress, FrameLayout.LayoutParams(dp(44), dp(44), Gravity.CENTER))
        root.addView(frame, LinearLayout.LayoutParams(-1, 0, 1f))

        tabBar = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; setBackgroundColor(Color.parseColor("#0E1430")) }
        root.addView(tabBar, LinearLayout.LayoutParams(-1, dp(58)))
        setContentView(root)
    }

    private fun buildTabs() {
        tabBar.removeAllViews()
        for (i in 0 until tabs.length()) {
            val t = tabs.getJSONObject(i); val id = t.getString("id")
            val v = TextView(this).apply {
                text = t.optString("icon") + "\n" + t.optString("label"); gravity = Gravity.CENTER; textSize = 11f
                setTextColor(if (id == tab) ACC2 else MUTED); setOnClickListener { selectTab(id) }
            }
            tabBar.addView(v, LinearLayout.LayoutParams(0, -1, 1f))
        }
    }

    private fun loadBoot() {
        progress.visibility = View.VISIBLE
        Thread {
            val r = Api.screen("boot", emptyMap())
            main.post {
                progress.visibility = View.GONE
                if (r.optBoolean("ok") && r.has("tabs")) {
                    tabs = r.getJSONArray("tabs"); site = r.optString("site", site)
                    if (stacks.isEmpty()) for (i in 0 until tabs.length()) stacks[tabs.getJSONObject(i).getString("id")] = arrayListOf()
                    buildTabs(); selectTab(tab)
                } else showError(r.optString("error", "შეცდომა")) { loadBoot() }
            }
        }.start()
    }

    private fun selectTab(id: String) {
        tab = id; buildTabs()
        val st = stacks.getOrPut(id) { arrayListOf() }
        if (st.isEmpty()) st.add(Frame(id, emptyMap()))
        reload()
    }

    private fun cur(): Frame? = stacks[tab]?.lastOrNull()
    private fun goBack() { val st = stacks[tab] ?: return; if (st.size > 1) { st.removeAt(st.size - 1); reload() } }
    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        val st = stacks[tab]
        if (st != null && st.size > 1) goBack()
        else if (tab != "home") selectTab("home")
        else super.onBackPressed()
    }

    // ---------------- ეკრანის ჩატვირთვა ----------------
    private fun reload() {
        val f = cur() ?: return
        val my = ++gen
        refreshRunnable?.let { main.removeCallbacks(it) }
        banner.visibility = View.GONE
        var p = f.params
        if (f.id == "weather" && !p.containsKey("lat") && !p.containsKey("city")) { val l = lastLocation(); if (l != null) p = p + mapOf("lat" to l.first.toString(), "lon" to l.second.toString()) }
        if (!swipe.isRefreshing && content.childCount == 0) progress.visibility = View.VISIBLE
        Thread {
            val r = Api.screen(f.id, p)
            main.post {
                if (my != gen) return@post
                progress.visibility = View.GONE; swipe.isRefreshing = false
                render(f, r)
            }
        }.start()
    }

    private fun showError(msg: String, retry: (() -> Unit)?) {
        content.removeAllViews()
        content.addView(TextView(this).apply { text = "⚠️ $msg"; setTextColor(TXT); textSize = 16f; gravity = Gravity.CENTER; setPadding(0, dp(40), 0, dp(16)) })
        if (retry != null) content.addView(button("თავიდან ცდა", "primary") { retry() })
    }

    private fun render(f: Frame, r: JSONObject) {
        content.removeAllViews(); fieldViews.clear()
        val st = stacks[tab]!!
        back.visibility = if (st.size > 1) View.VISIBLE else View.GONE
        if (!r.optBoolean("ok", true) || !r.has("blocks")) { title.text = site; showError(r.optString("error", "ეკრანი ვერ ჩაიტვირთა")) { reload() }; return }
        title.text = if (st.size > 1 || f.id != tab) r.optString("title", site) else site
        val blocks = r.getJSONArray("blocks")
        for (i in 0 until blocks.length()) addBlock(content, blocks.getJSONObject(i))
        val rf = r.optInt("refresh", 0)
        if (rf > 0) {
            val run = Runnable { if (fieldViews.none { it() }) reload() else refreshRunnable?.let { main.postDelayed(it, rf * 1000L) } }
            refreshRunnable = run; main.postDelayed(run, rf * 1000L)
        }
        if (r.optBoolean("wants_location") && !askedLoc && !hasLoc()) { askedLoc = true; ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION), REQ_LOC) }
    }

    // ---------------- მოქმედებები ----------------
    private fun perform(a: JSONObject?) {
        if (a == null) return
        when (a.optString("a")) {
            "screen" -> { stacks[tab]!!.add(Frame(a.getString("id"), params(a.optJSONObject("p")))); reload() }
            "replace" -> { val st = stacks[tab]!!; if (st.isNotEmpty()) st.removeAt(st.size - 1); st.add(Frame(a.getString("id"), params(a.optJSONObject("p")))); reload() }
            "root" -> {
                val id = a.getString("id"); val p = params(a.optJSONObject("p"))
                val target = if (isTab(id)) id else if (id == "login" || id == "register") "account" else tab
                stacks[target] = arrayListOf(Frame(if (isTab(id)) id else target, emptyMap()))
                if (!isTab(id)) stacks[target]!!.add(Frame(id, p))
                tab = target; buildTabs(); reload()
            }
            "back" -> goBack()
            "act" -> {
                val f = HashMap<String, String>(); a.optJSONObject("f")?.let { o -> o.keys().forEach { k -> f[k] = o.optString(k) } }
                val go = { doAct(a.getString("id"), f, emptyList(), null) }
                val c = a.optString("confirm")
                if (c.isNotEmpty()) AlertDialog.Builder(this).setMessage(c).setPositiveButton("დიახ") { _, _ -> go() }.setNegativeButton("გაუქმება", null).show() else go()
            }
            "url" -> try { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(a.getString("url")))) } catch (e: Exception) { toast("ბმული ვერ გაიხსნა") }
            "copy" -> { (getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager).setPrimaryClip(ClipData.newPlainText("t", a.optString("text"))); toast(a.optString("toast", "დაკოპირდა")) }
            "share" -> startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, a.optString("text")), "გაზიარება"))
            "app" -> {
                val i = packageManager.getLaunchIntentForPackage(a.optString("pkg"))
                try { if (i != null) startActivity(i) else if (a.optString("url").isNotEmpty()) startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(a.optString("url")))) } catch (e: Exception) { }
            }
        }
    }
    private fun isTab(id: String): Boolean { for (i in 0 until tabs.length()) if (tabs.getJSONObject(i).getString("id") == id) return true; return false }
    private fun params(o: JSONObject?): Map<String, String> { val m = HashMap<String, String>(); o?.keys()?.forEach { k -> m[k] = o.optString(k) }; return m }

    private fun doAct(id: String, f: Map<String, String>, files: List<UploadFile>, done: (() -> Unit)?) {
        progress.visibility = View.VISIBLE
        Thread {
            val r = Api.act(id, f, files)
            main.post {
                progress.visibility = View.GONE; done?.invoke()
                if (r.optString("token").isNotEmpty()) { Api.token = r.getString("token") }
                if (r.optBoolean("logout")) { Api.token = ""; }
                if (r.optBoolean("ok")) {
                    if (r.optString("toast").isNotEmpty()) say(r.getString("toast"), true)
                    if (r.optString("token").isNotEmpty() || r.optBoolean("logout")) {
                        // ტაბების სახელები (შესვლა/ანგარიში) განახლდეს
                        val nav = r.optJSONObject("nav")
                        for (k in stacks.keys) stacks[k] = arrayListOf()
                        Thread { val b = Api.screen("boot", emptyMap()); main.post { if (b.has("tabs")) tabs = b.getJSONArray("tabs"); buildTabs(); if (nav != null) perform(nav) else selectTab("home") } }.start()
                    } else if (r.optJSONObject("nav") != null) perform(r.optJSONObject("nav")) else if (id.endsWith("_send") || id.endsWith("_check")) { /* ფორმა რჩება */ }
                } else say(r.optString("error", "შეცდომა"), false)
            }
        }.start()
    }

    private fun say(msg: String, ok: Boolean) {
        banner.text = msg; banner.setBackgroundColor(if (ok) Color.parseColor("#1E7F4F") else Color.parseColor("#9B2C30")); banner.visibility = View.VISIBLE
        main.postDelayed({ if (banner.text == msg) banner.visibility = View.GONE }, if (ok) 4000 else 7000)
    }
    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()

    // ---------------- ბლოკები ----------------
    private fun lp(top: Int = 0, bottom: Int = 10) = LinearLayout.LayoutParams(-1, -2).apply { setMargins(0, dp(top), 0, dp(bottom)) }
    private fun tv(text: String, size: Float, color: Int = TXT, bold: Boolean = false) = TextView(this).apply {
        this.text = text; textSize = size; setTextColor(color); if (bold) typeface = Typeface.DEFAULT_BOLD; setLineSpacing(0f, 1.15f)
    }
    private fun button(label: String, style: String, onClick: () -> Unit) = Button(this).apply {
        text = label; isAllCaps = false; textSize = 15f; setTextColor(TXT)
        background = when (style) { "secondary" -> bg(CARD, 12, LINE); "danger" -> bg(RED, 12); else -> bg(ACC, 12) }
        setPadding(dp(14), dp(12), dp(14), dp(12)); layoutParams = lp(0, 10); setOnClickListener { onClick() }
    }

    private fun addBlock(parent: LinearLayout, b: JSONObject) {
        when (b.optString("t")) {
            "hero" -> parent.addView(LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL; background = GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(ACC, Color.parseColor("#3A2FA8"))).apply { cornerRadius = dp(16).toFloat() }
                setPadding(dp(18), dp(22), dp(18), dp(22)); addView(tv(b.optString("title"), 22f, TXT, true))
                if (b.optString("sub").isNotEmpty()) addView(tv(b.optString("sub"), 14f, Color.parseColor("#DAD6FF")).apply { setPadding(0, dp(6), 0, 0) })
            }, lp(0, 14))
            "text" -> {
                val s = b.optString("style")
                parent.addView(when (s) {
                    "h1" -> tv(b.optString("text"), 21f, TXT, true); "h2" -> tv(b.optString("text"), 17f, TXT, true).apply { setPadding(0, dp(8), 0, 0) }
                    "muted" -> tv(b.optString("text"), 13f, MUTED); "small" -> tv(b.optString("text"), 12f, MUTED)
                    "center" -> tv(b.optString("text"), 15f).apply { gravity = Gravity.CENTER }
                    else -> tv(b.optString("text"), 15f, Color.parseColor("#DDE3FF")) }, lp(0, 10))
            }
            "button" -> { val act = b.optJSONObject("action"); parent.addView(button(b.optString("label"), b.optString("style")) { perform(act) }) }
            "notice" -> {
                val c = when (b.optString("kind")) { "ok" -> GREEN; "warn" -> AMBER; "error" -> RED; else -> ACC2 }
                parent.addView(tv(b.optString("text"), 14f).apply { background = bg(Color.argb(40, Color.red(c), Color.green(c), Color.blue(c)), 12, c); setPadding(dp(14), dp(12), dp(14), dp(12)) }, lp(0, 12))
            }
            "card" -> {
                val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; background = bg(CARD, 14, LINE) }
                if (b.optString("image").isNotEmpty()) box.addView(ImageView(this).apply { scaleType = ImageView.ScaleType.CENTER_CROP; setBackgroundColor(Color.parseColor("#0B0F1F")); Img.load(this, b.getString("image")) }, LinearLayout.LayoutParams(-1, dp(170)))
                val inner = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(14), dp(12), dp(14), dp(12)) }
                val head = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
                head.addView(tv(b.optString("title"), 16f, TXT, true), LinearLayout.LayoutParams(0, -2, 1f))
                if (b.optString("price").isNotEmpty()) head.addView(tv(b.optString("price"), 16f, ACC2, true))
                inner.addView(head)
                val lines = b.optJSONArray("lines"); if (lines != null) for (i in 0 until lines.length()) { val l = lines.optString(i); if (l.isNotEmpty()) inner.addView(tv(l, 13.5f, MUTED).apply { setPadding(0, dp(4), 0, 0) }) }
                if (b.optString("badge").isNotEmpty()) inner.addView(tv(b.optString("badge"), 12f, ACC2, true).apply { setPadding(0, dp(8), 0, 0) })
                box.addView(inner)
                val act = b.optJSONObject("action"); if (act != null) box.setOnClickListener { perform(act) }
                parent.addView(box, lp(0, 12))
            }
            "kv" -> {
                val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; background = bg(CARD, 14, LINE); setPadding(dp(14), dp(10), dp(14), dp(10)) }
                if (b.optString("title").isNotEmpty()) box.addView(tv(b.optString("title"), 15f, TXT, true).apply { setPadding(0, 0, 0, dp(6)) })
                val rows = b.optJSONArray("rows") ?: JSONArray()
                for (i in 0 until rows.length()) { val r = rows.getJSONArray(i)
                    box.addView(LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; setPadding(0, dp(5), 0, dp(5))
                        addView(tv(r.optString(0), 14f, MUTED), LinearLayout.LayoutParams(0, -2, 1f)); addView(tv(r.optString(1), 14f, TXT, true).apply { gravity = Gravity.END }, LinearLayout.LayoutParams(0, -2, 1.2f)) }) }
                parent.addView(box, lp(0, 12))
            }
            "list" -> {
                if (b.optString("title").isNotEmpty()) parent.addView(tv(b.optString("title"), 15f, ACC2, true), lp(6, 6))
                val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; background = bg(CARD, 14, LINE) }
                val items = b.optJSONArray("items") ?: JSONArray()
                for (i in 0 until items.length()) {
                    val it = items.getJSONObject(i)
                    val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(dp(14), dp(13), dp(14), dp(13)) }
                    val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
                    col.addView(tv(it.optString("title"), 15f)); if (it.optString("sub").isNotEmpty()) col.addView(tv(it.optString("sub"), 12.5f, MUTED))
                    row.addView(col, LinearLayout.LayoutParams(0, -2, 1f))
                    if (it.optString("right").isNotEmpty()) row.addView(tv(it.optString("right"), 14f, ACC2, true))
                    val act = it.optJSONObject("action"); if (act != null) { row.addView(tv("›", 20f, MUTED).apply { setPadding(dp(8), 0, 0, 0) }); row.setOnClickListener { perform(act) } }
                    box.addView(row)
                    if (i < items.length() - 1) box.addView(View(this).apply { setBackgroundColor(LINE) }, LinearLayout.LayoutParams(-1, 1))
                }
                parent.addView(box, lp(0, 12))
            }
            "image" -> parent.addView(ImageView(this).apply { scaleType = ImageView.ScaleType.FIT_CENTER; adjustViewBounds = true; background = bg(Color.parseColor("#0B0F1F"), 12); Img.load(this, b.optString("url")) }, lp(0, 12))
            "copyfield" -> {
                val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; background = bg(CARD, 12, ACC); setPadding(dp(14), dp(10), dp(14), dp(10)) }
                box.addView(tv(b.optString("label"), 12f, MUTED)); box.addView(tv(b.optString("value"), 14f, TXT, true).apply { setTextIsSelectable(true) })
                box.addView(tv("კოპირება", 13f, ACC2, true).apply { setPadding(0, dp(6), 0, 0); setOnClickListener { perform(JSONObject().put("a", "copy").put("text", b.optString("value"))) } })
                parent.addView(box, lp(0, 10))
            }
            "qr" -> parent.addView(tv(b.optString("value"), 13f, MUTED), lp(0, 10))
            "divider" -> parent.addView(View(this).apply { setBackgroundColor(LINE) }, LinearLayout.LayoutParams(-1, 1).apply { setMargins(0, dp(8), 0, dp(8)) })
            "spacer" -> parent.addView(View(this), LinearLayout.LayoutParams(-1, dp(b.optInt("h", 12))))
            "chips" -> {
                val hs = HorizontalScrollView(this).apply { isHorizontalScrollBarEnabled = false }
                val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
                val items = b.optJSONArray("items") ?: JSONArray()
                for (i in 0 until items.length()) { val it = items.getJSONObject(i); val act = it.optJSONObject("action")
                    row.addView(tv(it.optString("label"), 14f).apply { background = bg(CARD, 20, LINE); setPadding(dp(14), dp(8), dp(14), dp(8)); setOnClickListener { perform(act) } }, LinearLayout.LayoutParams(-2, -2).apply { setMargins(0, 0, dp(8), 0) }) }
                hs.addView(row); parent.addView(hs, lp(0, 12))
            }
            "bubble" -> {
                val mine = b.optBoolean("mine")
                val bub = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; background = bg(if (mine) ACC else CARD, 14, if (mine) 0 else LINE); setPadding(dp(12), dp(8), dp(12), dp(8)) }
                bub.addView(tv(b.optString("text"), 14.5f)); bub.addView(tv(b.optString("time"), 11f, if (mine) Color.parseColor("#DAD6FF") else MUTED))
                parent.addView(bub, LinearLayout.LayoutParams(-2, -2).apply { gravity = if (mine) Gravity.END else Gravity.START; setMargins(if (mine) dp(48) else 0, dp(2), if (mine) 0 else dp(48), dp(6)) })
            }
            "form" -> addForm(parent, b)
        }
    }

    // ---------------- ფორმა ----------------
    private fun addForm(parent: LinearLayout, b: JSONObject) {
        val getters = LinkedHashMap<String, () -> String>()
        val files = HashMap<String, Uri?>()
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; background = bg(CARD, 14, LINE); setPadding(dp(14), dp(14), dp(14), dp(8)) }
        val fields = b.getJSONArray("fields")
        for (i in 0 until fields.length()) {
            val f = fields.getJSONObject(i); val name = f.getString("name"); val type = f.optString("type"); val label = f.optString("label")
            if (type == "hidden") { val v = f.optString("value"); getters[name] = { v }; continue }
            if (type == "actionbtn") {
                val uses = f.optJSONArray("uses") ?: JSONArray()
                val btn = button(f.optString("btn"), "secondary") { }
                btn.setOnClickListener {
                    val m = HashMap<String, String>(); for (u in 0 until uses.length()) { val k = uses.getString(u); m[k] = getters[k]?.invoke() ?: "" }
                    btn.isEnabled = false; doAct(f.getString("act"), m, emptyList()) { btn.isEnabled = true }
                }
                box.addView(btn); continue
            }
            if (label.isNotEmpty() && type != "checkbox") box.addView(tv(label, 13f, MUTED).apply { setPadding(0, dp(4), 0, dp(4)) })
            when (type) {
                "select" -> {
                    val opts = f.optJSONArray("options") ?: JSONArray(); val vals = ArrayList<String>(); val labs = ArrayList<String>()
                    for (k in 0 until opts.length()) { val o = opts.getJSONArray(k); vals.add(o.optString(0)); labs.add(o.optString(1)) }
                    val sp = Spinner(this); sp.adapter = object : ArrayAdapter<String>(this, android.R.layout.simple_spinner_dropdown_item, labs) {
                        override fun getView(p: Int, c: View?, g: ViewGroup): View = (super.getView(p, c, g) as TextView).apply { setTextColor(TXT) }
                    }
                    val idx = vals.indexOf(f.optString("value")); if (idx >= 0) sp.setSelection(idx)
                    sp.background = bg(Color.parseColor("#0E1430"), 10, LINE)
                    box.addView(sp, lp(0, 10)); getters[name] = { if (vals.isEmpty()) "" else vals[sp.selectedItemPosition] }
                }
                "checkbox" -> { val cb = CheckBox(this).apply { text = label; setTextColor(TXT); isChecked = f.optString("value") == "1" }; box.addView(cb, lp(0, 8)); getters[name] = { if (cb.isChecked) "1" else "0" } }
                "file" -> {
                    val info = tv("ფაილი არ არის არჩეული", 13f, MUTED)
                    box.addView(button("📎 ფაილის არჩევა", "secondary") {
                        pickTarget = { uri -> files[name] = uri; info.text = "✔ არჩეულია"; info.setTextColor(GREEN) }
                        val i = Intent(Intent.ACTION_GET_CONTENT).setType("*/*").addCategory(Intent.CATEGORY_OPENABLE).putExtra(Intent.EXTRA_MIME_TYPES, arrayOf("image/*", "application/pdf"))
                        startActivityForResult(Intent.createChooser(i, "აირჩიეთ ქვითარი"), REQ_PICK)
                    }); box.addView(info, lp(0, 10)); getters[name] = { if (files[name] != null) "1" else "" }
                }
                else -> {
                    val et = EditText(this).apply {
                        hint = f.optString("placeholder"); setHintTextColor(Color.parseColor("#59638C")); setTextColor(TXT); textSize = 15f; background = bg(Color.parseColor("#0E1430"), 10, LINE); setPadding(dp(12), dp(11), dp(12), dp(11))
                        setText(f.optString("value"))
                        inputType = when (type) { "email" -> InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_EMAIL_ADDRESS; "password" -> InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
                            "phone" -> InputType.TYPE_CLASS_NUMBER; "number" -> InputType.TYPE_CLASS_NUMBER; "textarea" -> InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE or InputType.TYPE_TEXT_FLAG_CAP_SENTENCES; else -> InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_CAP_SENTENCES }
                        if (type == "textarea") { minLines = 3; gravity = Gravity.TOP }
                    }
                    box.addView(et, lp(0, 6)); getters[name] = { et.text.toString().trim() }
                    fieldViews.add { et.text.isNotEmpty() && type != "hidden" }
                    if (f.optString("hint").isNotEmpty()) box.addView(tv(f.optString("hint"), 11.5f, MUTED), lp(0, 8))
                }
            }
        }
        val sub = b.getJSONObject("submit")
        val btn = button(sub.optString("label"), "primary") { }
        btn.setOnClickListener {
            val m = HashMap<String, String>()
            for ((k, g) in getters) m[k] = g()
            sub.optJSONObject("f")?.let { o -> o.keys().forEach { k -> m[k] = o.optString(k) } }
            // ფაილის ველების მნიშვნელობები (ბაიტები კი multipart-ით მიდის)
            val up = ArrayList<UploadFile>(); for ((k, u) in files) if (u != null) { up.add(UploadFile(k, u)); m.remove(k) }
            (currentFocus)?.let { (getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager).hideSoftInputFromWindow(it.windowToken, 0) }
            btn.isEnabled = false; doAct(sub.getString("act"), m, up) { btn.isEnabled = true }
        }
        box.addView(btn, lp(6, 6))
        parent.addView(box, lp(0, 14))
    }

    // ---------------- ლოკაცია / ფაილი ----------------
    private fun hasLoc() = ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED || ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED
    @Suppress("MissingPermission")
    private fun lastLocation(): Pair<Double, Double>? {
        if (!hasLoc()) return null
        return try {
            val lm = getSystemService(Context.LOCATION_SERVICE) as LocationManager
            var best: android.location.Location? = null
            for (p in lm.getProviders(true)) { val l = lm.getLastKnownLocation(p) ?: continue; if (best == null || l.time > best.time) best = l }
            best?.let { Pair(it.latitude, it.longitude) }
        } catch (e: Exception) { null }
    }
    override fun onRequestPermissionsResult(code: Int, perms: Array<out String>, res: IntArray) {
        super.onRequestPermissionsResult(code, perms, res)
        if (code == REQ_LOC && hasLoc() && cur()?.id == "weather") reload()
    }
    @Deprecated("Deprecated in Java")
    override fun onActivityResult(req: Int, res: Int, data: Intent?) {
        super.onActivityResult(req, res, data)
        if (req == REQ_PICK && res == Activity.RESULT_OK) data?.data?.let { pickTarget?.invoke(it) }
    }
}
